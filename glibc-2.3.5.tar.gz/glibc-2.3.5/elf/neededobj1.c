extern void c_function (void);

void
c_function (void)
{
}
