int foo (void);
int weak (void);

int foo (void)
{
  return 10;
}

int weak (void)
{
  return 30;
}
