int foo (void);

int foo (void)
{
  return 0;
}

