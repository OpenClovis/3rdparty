int dummy1;
