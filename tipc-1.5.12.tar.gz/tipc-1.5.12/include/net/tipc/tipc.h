/* ------------------------------------------------------------------------
 *
 * tipc.h
 *
 * Short description: Main include file for TIPC users
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2003-10-20 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  Revision history:
 *  ----------------
 *
 *  PA1	2003-10-20	Jon Maloy	Created.
 *
 * ------------------------------------------------------------------------
 */

#ifndef __NET_TIPC_H_
#define __NET_TIPC_H_

#include <linux/types.h>

/*
 * TIPC addressing primitives
 */
 
struct tipc_portid {
	__u32 ref;
	__u32 node;
};

struct tipc_name {
	__u32 type;
	__u32 instance;
};

struct tipc_name_seq {
	__u32 type;
	__u32 lower;
	__u32 upper;
};

static inline __u32 tipc_addr(unsigned int zone,
			      unsigned int cluster,
			      unsigned int node)
{
	return(zone << 24) | (cluster << 12) | node;
}

static inline unsigned int tipc_zone(__u32 addr)
{
	return  addr >> 24;
}

static inline unsigned int tipc_cluster(__u32 addr)
{
	return(addr >> 12) & 0xfff;
}

static inline unsigned int tipc_node(__u32 addr)
{
	return  addr & 0xfff;
}

/*
 * Application-accessible port name types
 */

#define TIPC_NET_EVENTS		0	/* network event subscription name type */
#define TIPC_TOP_SRV         	1  	/* topology service name type */
#define TIPC_RESERVED_TYPES	64	/* lowest user-publishable name type */

/* 
 * Publication scopes when binding port names and port name sequences
 */

#define TIPC_ZONE_SCOPE         1
#define TIPC_CLUSTER_SCOPE      2     
#define TIPC_NODE_SCOPE         3

/*
 * Limiting values for messages
 */

#define TIPC_MAX_USER_MSG_SIZE 66000

/* 
 * Message importance levels
 */

#define TIPC_LOW_IMPORTANCE     	0  /* default */
#define TIPC_MEDIUM_IMPORTANCE		1
#define TIPC_HIGH_IMPORTANCE		2
#define TIPC_CRITICAL_IMPORTANCE	3

/* 
 * Msg rejection/connection shutdown reasons
 */

#define TIPC_OK			0
#define TIPC_ERR_NO_NAME	1
#define TIPC_ERR_NO_PORT	2
#define TIPC_ERR_NO_NODE	3
#define TIPC_ERR_OVERLOAD	4
#define TIPC_CONN_SHUTDOWN	5


/*
 * TIPC topology subscription service definitions
 */

#define TIPC_SUB_PORTS     	0x01  	/* filter for port availability */
#define TIPC_SUB_SERVICE     	0x02  	/* filter for service availability */
#if 0
/* The following filter options are not currently implemented */
#define TIPC_SUB_NO_BIND_EVTS	0x04	/* filter out "publish" events */
#define TIPC_SUB_NO_UNBIND_EVTS	0x08	/* filter out "withdraw" events */
#define TIPC_SUB_SINGLE_EVT	0x10	/* expire after first event */
#endif

#define TIPC_WAIT_FOREVER   	~0	/* timeout for permanent subscription */

struct tipc_subscr {
	struct tipc_name_seq seq;	/* name sequence of interest */
	__u32 timeout;			/* subscription duration (in ms) */
        __u32 filter;   		/* bitmask of filter options */
	char usr_handle[8];		/* available for subscriber use */
};


#define TIPC_PUBLISHED          1	/* publication event */
#define TIPC_WITHDRAWN          2	/* withdraw event */
#define TIPC_SUBSCR_TIMEOUT     3	/* subscription timeout event */

struct tipc_event {
	__u32 event;			/* event type */
	__u32 found_lower;		/* matching name seq instances */
	__u32 found_upper;		/*    "      "    "     "      */
        struct tipc_portid port;	/* associated port */
	struct tipc_subscr s;		/* associated subscription */
};


/*
 * Socket API
 * ----------
 */

#define AF_TIPC	30 /* SOCK_STREAM,SOCK_SEQPACKET,SOCK_RDM,SOCK_DGRAM */


#define TIPC_ADDR_NAMESEQ   	1
#define TIPC_ADDR_MCAST         1
#define TIPC_ADDR_NAME      	2
#define TIPC_ADDR_ID        	3


struct sockaddr_tipc {
	unsigned short family;
	unsigned char  addrtype;
	signed   char  scope;
	union {
		struct tipc_portid id;
		struct tipc_name_seq nameseq;
		struct {
			struct tipc_name name;
			__u32 domain; /* 0: own zone */
		} name;
	} addr;
};


/*
 * Ancillary data objects supported by recvmsg()
 */

#define TIPC_ERRINFO	1	/* error info */
#define TIPC_RETDATA	2	/* returned data */
#define TIPC_DESTNAME	3	/* destination name */

/*
 * TIPC-specific socket option values
 */

#define SOL_TIPC		50	/* TIPC socket option level */
#define TIPC_IMPORTANCE		127	/* Default: TIPC_LOW_IMPORTANCE */
#define TIPC_SRC_DROPPABLE	128	/* Default: 0 (resend congested msg) */
#define TIPC_DEST_DROPPABLE	129	/* Default: based on socket type */
#define TIPC_CONN_TIMEOUT     	130	/* Default: 8000 (ms)  */


#ifdef __KERNEL__

/* 
 * Native API
 * ----------
 */

#include <linux/skbuff.h>


/*
 * TIPC operating mode routines
 */

u32 tipc_get_addr(void);


#define TIPC_NOT_RUNNING  0
#define TIPC_NODE_MODE    1
#define TIPC_NET_MODE     2

typedef void (*tipc_mode_event)(void *usr_handle, int mode, u32 addr);

int tipc_attach(unsigned int *userref, tipc_mode_event, void *usr_handle);

void tipc_detach(unsigned int userref);

int tipc_get_mode(void);

/*
 * TIPC port manipulation routines
 */

typedef void (*tipc_msg_err_event) (void *usr_handle,
				    u32 portref,
				    struct sk_buff **buf,
				    unsigned char const *data,
				    unsigned int size,
				    int reason, 
				    struct tipc_portid const *attmpt_destid);

typedef void (*tipc_named_msg_err_event) (void *usr_handle,
					  u32 portref,
					  struct sk_buff **buf,
					  unsigned char const *data,
					  unsigned int size,
					  int reason, 
					  struct tipc_name_seq const *attmpt_dest);

typedef void (*tipc_conn_shutdown_event) (void *usr_handle,
					  u32 portref,
					  struct sk_buff **buf,
					  unsigned char const *data,
					  unsigned int size,
					  int reason);

typedef void (*tipc_msg_event) (void *usr_handle,
				u32 portref,
				struct sk_buff **buf,
				unsigned char const *data,
				unsigned int size,
				unsigned int importance, 
				struct tipc_portid const *origin);

typedef void (*tipc_named_msg_event) (void *usr_handle,
				      u32 portref,
				      struct sk_buff **buf,
				      unsigned char const *data,
				      unsigned int size,
				      unsigned int importance, 
				      struct tipc_portid const *orig,
				      struct tipc_name_seq const *dest);

typedef void (*tipc_conn_msg_event) (void *usr_handle,
				     u32 portref,
				     struct sk_buff **buf,
				     unsigned char const *data,
				     unsigned int size);

typedef void (*tipc_continue_event) (void *usr_handle, 
				     u32 portref);

int tipc_createport(unsigned int tipc_user, 
		    void *usr_handle, 
		    unsigned int importance, 
		    tipc_msg_err_event error_cb, 
		    tipc_named_msg_err_event named_error_cb, 
		    tipc_conn_shutdown_event conn_error_cb, 
		    tipc_msg_event message_cb, 
		    tipc_named_msg_event named_message_cb, 
		    tipc_conn_msg_event conn_message_cb, 
		    tipc_continue_event continue_event_cb,/* May be zero */
		    u32 *portref);

int tipc_deleteport(u32 portref);

int tipc_ownidentity(u32 portref, struct tipc_portid *port);

int tipc_portimportance(u32 portref, unsigned int *importance);
int tipc_set_portimportance(u32 portref, unsigned int importance);

int tipc_portunreliable(u32 portref, unsigned int *isunreliable);
int tipc_set_portunreliable(u32 portref, unsigned int isunreliable);

int tipc_portunreturnable(u32 portref, unsigned int *isunreturnable);
int tipc_set_portunreturnable(u32 portref, unsigned int isunreturnable);

int tipc_publish(u32 portref, unsigned int scope, 
		 struct tipc_name_seq const *name_seq);
int tipc_withdraw(u32 portref, unsigned int scope,
		  struct tipc_name_seq const *name_seq); /* 0: all */

int tipc_connect2port(u32 portref, struct tipc_portid const *port);

int tipc_disconnect(u32 portref);

int tipc_shutdown(u32 ref); /* Sends SHUTDOWN msg */

int tipc_isconnected(u32 portref, int *isconnected);

int tipc_peer(u32 portref, struct tipc_portid *peer);

int tipc_ref_valid(u32 portref); 

/*
 * TIPC messaging routines
 */

#define TIPC_PORT_IMPORTANCE 100	/* send using current port setting */


int tipc_send(u32 portref,
	      unsigned int num_sect,
	      struct iovec const *msg_sect);

int tipc_send_buf(u32 portref,
		  struct sk_buff *buf,
		  unsigned int dsz);

int tipc_send2name(u32 portref, 
		   struct tipc_name const *name, 
		   u32 domain,	/* 0:own zone */
		   unsigned int num_sect,
		   struct iovec const *msg_sect);

int tipc_send_buf2name(u32 portref,
		       struct tipc_name const *name,
		       u32 domain,
		       struct sk_buff *buf,
		       unsigned int dsz);

int tipc_forward2name(u32 portref, 
		      struct tipc_name const *name, 
		      u32 domain,   /*0: own zone */
		      unsigned int section_count,
		      struct iovec const *msg_sect,
		      struct tipc_portid const *origin,
		      unsigned int importance);

int tipc_forward_buf2name(u32 portref,
			  struct tipc_name const *name,
			  u32 domain,
			  struct sk_buff *buf,
			  unsigned int dsz,
			  struct tipc_portid const *orig,
			  unsigned int importance);

int tipc_send2port(u32 portref,
		   struct tipc_portid const *dest,
		   unsigned int num_sect,
		   struct iovec const *msg_sect);

int tipc_send_buf2port(u32 portref,
		       struct tipc_portid const *dest,
		       struct sk_buff *buf,
		       unsigned int dsz);

int tipc_forward2port(u32 portref,
		      struct tipc_portid const *dest,
		      unsigned int num_sect,
		      struct iovec const *msg_sect,
		      struct tipc_portid const *origin,
		      unsigned int importance);

int tipc_forward_buf2port(u32 portref,
			  struct tipc_portid const *dest,
			  struct sk_buff *buf,
			  unsigned int dsz,
			  struct tipc_portid const *orig,
			  unsigned int importance);

int tipc_multicast(u32 portref, 
		   struct tipc_name_seq const *seq, 
		   u32 domain,	/* 0:own zone */
		   unsigned int section_count,
		   struct iovec const *msg);

#if 0
int tipc_multicast_buf(u32 portref, 
		       struct tipc_name_seq const *seq, 
		       u32 domain,	/* 0:own zone */
		       void *buf,
		       unsigned int size);
#endif

/*
 * TIPC subscription routines
 */

int tipc_ispublished(struct tipc_name const *name);

/*
 * Get number of available nodes within specified domain (excluding own node)
 */

unsigned int tipc_available_nodes(const u32 domain);

#endif

#endif
