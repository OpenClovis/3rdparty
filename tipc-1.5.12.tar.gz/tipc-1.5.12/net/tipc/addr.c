/* --------------------------------------------------------------------
 *
 * addr.c
 *
 * Short description: TIPC address utility routines
 *     
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2004-2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-09-30 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: addr.c,v 1.17 2005/11/16 20:32:00 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: addr.c,v $
 *  Revision 1.17  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.16  2005/11/09 19:35:32  jonmaloy
 *  Added MTU negotiation and stale check in link protocol
 *
 *  Revision 1.15  2005/10/26 17:24:44  ajstephens
 *  fix addr_node_valid() to disallow address of form <x.x.0>
 *
 *  Revision 1.14  2005/06/16 12:49:29  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.13  2005/06/01 19:13:26  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.12  2005/06/01 13:04:00  ajstephens
 *  Link/bearer/media name rework; continued cleanup
 *
 *  Revision 1.11  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.10  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.9  2004/08/19 14:23:56  ajstephens
 *  Standardize spacing in TIPC system messages.
 *
 *  Revision 1.8  2004/06/22 01:42:47  jonmaloy
 *  Removed macro k_malloc and typedef tipc_net_addr_t
 *
 *  Revision 1.7  2004/06/16 16:38:34  jonmaloy
 *  Corrected previous correction
 *
 *  Revision 1.6  2004/06/16 16:35:00  jonmaloy
 *  Eliminated risk of addr_string_area overflow
 *
 *  Revision 1.3  2003/05/16 20:49:54  telorb
 *  Checked in with epsi by lmcjoma
 *
 *  Revision 1.0 2003/02/02 03:51:00   lmcabda
 *  Released as an Open Source product under the BSD License
 *
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	2000-09-30	Jon Maloy	Created
 *
 * ------------------------------------------------------------------------
 */

#include "core.h"
#include "dbg.h"
#include "addr.h"
#include "zone.h"
#include "cluster.h"
#include "net.h"

u32 tipc_get_addr(void)
{
	return tipc_own_addr;
}

/**
 * addr_domain_valid - validates a network domain address
 * 
 * Accepts <Z.C.N>, <Z.C.0>, <Z.0.0>, and <0.0.0>, 
 * where Z, C, and N are non-zero and do not exceed the configured limits.
 * 
 * Returns 1 if domain address is valid, otherwise 0
 */

int addr_domain_valid(u32 addr)
{
	u32 n = tipc_node(addr);
	u32 c = tipc_cluster(addr);
	u32 z = tipc_zone(addr);
	u32 max_nodes = tipc_max_nodes;

	if (is_slave(addr))
		max_nodes = LOWEST_SLAVE + tipc_max_slaves;
	if (n > max_nodes)
		return 0;
	if (c > tipc_max_clusters)
		return 0;
	if (z > tipc_max_zones)
		return 0;

	if (n && (!z || !c))
		return 0;
	if (c && !z)
		return 0;
	return 1;
}

/**
 * addr_node_valid - validates a proposed network address for this node
 * 
 * Accepts <Z.C.N>, where Z, C, and N are non-zero and do not exceed 
 * the configured limits.
 * 
 * Returns 1 if address can be used, otherwise 0
 */

int addr_node_valid(u32 addr)
{
	return (addr_domain_valid(addr) && tipc_node(addr));
}

