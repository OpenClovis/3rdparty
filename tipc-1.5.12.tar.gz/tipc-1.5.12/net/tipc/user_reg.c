/* ------------------------------------------------------------------------
 * user_reg.c
 *
 * Short description: TIPC user registry code
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2004-2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-09-30 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: user_reg.c,v 1.8 2005/12/05 18:04:54 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: user_reg.c,v $
 *  Revision 1.8  2005/12/05 18:04:54  ajstephens
 *  Modified tipc_attach() to use POSIX errno values.
 *
 *  Revision 1.7  2005/11/23 16:47:36  jonmaloy
 *  Cleared callback pointer in tipc_detach()
 *
 *  Revision 1.6  2005/10/12 19:13:39  ajstephens
 *  Reworked signal and timer code; eliminate risk of timers expiring after unloading
 *
 *  Revision 1.5  2005/09/08 21:38:01  jonmaloy
 *  Fixed race condition between neighbour detection and tipc_stop_net
 *
 *  Revision 1.4  2005/06/16 12:49:31  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.3  2005/06/07 15:11:00  ajstephens
 *  Cleaned up native port API; exported missing symbols for native API
 *
 *  Revision 1.2  2005/06/06 21:23:58  ajstephens
 *  More cleanup (fix max header size, add null checks, errno standardization, etc.)
 *
 *  Revision 1.1  2005/06/01 19:13:28  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.27  2005/06/01 13:04:02  ajstephens
 *  Link/bearer/media name rework; continued cleanup
 *
 *  Revision 1.26  2005/05/30 02:21:08  jonmaloy
 *  Corrected bugs related to tipc_detach
 *
 *  Revision 1.25  2005/05/29 18:56:32  jonmaloy
 *  New topology subscription infrastructure
 *
 *  Revision 1.24  2005/05/25 12:39:24  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.23  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.22  2005/03/23 17:03:26  jonmaloy
 *  Fixed bug in connect(). Now returns correct negative value at failure
 *
 *  Revision 1.21  2005/03/21 22:54:14  jonmaloy
 *  Using vmalloc/vfree for port reference table
 *
 *  Revision 1.20  2005/03/08 19:03:07  jonmaloy
 *  Removed buf_safe_discard(). Made buf_discard() safe.
 *
 *  Revision 1.16  2004/08/19 14:54:49  ajstephens
 *  Standardize spacing in TIPC system messages.
 *
 *  Revision 1.9  2004/05/12 21:14:31  markhaverkamp
 *  Fix a spinlock deadlock.
 *  A few other misc. fixes.
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	2000-09-30	Jon Maloy	Created
 *
 * ------------------------------------------------------------------------
*/

#include "core.h"
#include "user_reg.h"

/*
 * TIPC user registry keeps track of users of the tipc_port interface.
 *
 * The registry utilizes an array of "TIPC user" entries; 
 * a user's ID is the index of their associated array entry.
 * Array entry 0 is not used, so userid 0 is not valid;
 * TIPC sometimes uses this value to denote an anonymous user.
 * The list of free entries is initially chained from last entry to entry 1.
 */

/**
 * struct tipc_user - registered TIPC user info
 * @next: index of next free registry entry (or -1 for an allocated entry)
 * @callback: ptr to routine to call when TIPC mode changes (NULL if none)
 * @usr_handle: user-defined value passed to callback routine 
 * @ports: list of user ports owned by the user
 */

struct tipc_user {
	int next;
	tipc_mode_event callback;
	void *usr_handle;
	struct list_head ports;
};

#define MAX_USERID 64
#define USER_LIST_SIZE ((MAX_USERID + 1) * sizeof(struct tipc_user))

static struct tipc_user *users = 0;
static u32 next_free_user = MAX_USERID + 1;
static spinlock_t reg_lock = SPIN_LOCK_UNLOCKED;

/**
 * reg_init - create TIPC user registry (but don't activate it)
 * 
 * If registry has been pre-initialized it is left "as is".
 * NOTE: This routine may be called when TIPC is inactive.
 */

static int reg_init(void)
{
	u32 i;
	
	spin_lock_bh(&reg_lock);
	if (!users) {
		users = (struct tipc_user *)kmalloc(USER_LIST_SIZE, GFP_ATOMIC);
		if (users) {
			memset(users, 0, USER_LIST_SIZE);
			for (i = 1; i <= MAX_USERID; i++) {
				users[i].next = i - 1;
			}
			next_free_user = MAX_USERID;
		}
	}
	spin_unlock_bh(&reg_lock);
	return users ? TIPC_OK : -ENOMEM;
}

/**
 * reg_callback - inform TIPC user about current operating mode
 */

static void reg_callback(struct tipc_user *user_ptr)
{
	tipc_mode_event cb;
	void *arg;

	spin_lock_bh(&reg_lock);
	cb = user_ptr->callback;
	arg = user_ptr->usr_handle;
	spin_unlock_bh(&reg_lock);

	if (cb)
		cb(arg, tipc_mode, tipc_own_addr);
}

/**
 * reg_start - activate TIPC user registry
 */

int reg_start(void)
{
	u32 u;
	int res;

	if ((res = reg_init()))
		return res;

	for (u = 1; u <= MAX_USERID; u++) {
		if (users[u].callback)
			k_signal((Handler)reg_callback,
				 (unsigned long)&users[u]);
	}
	return TIPC_OK;
}

/**
 * reg_stop - shut down & delete TIPC user registry
 */

void reg_stop(void)
{               
	int id;

	if (!users)
		return;

	for (id = 1; id <= MAX_USERID; id++) {
		if (users[id].callback)
			reg_callback(&users[id]);
	}
	kfree(users);
	users = 0;
}

/**
 * tipc_attach - register a TIPC user
 *
 * NOTE: This routine may be called when TIPC is inactive.
 */

int tipc_attach(u32 *userid, tipc_mode_event cb, void *usr_handle)
{
	struct tipc_user *user_ptr;

	if ((tipc_mode == TIPC_NOT_RUNNING) && !cb)
		return -ENOPROTOOPT;
	if (!users)
		reg_init();

	spin_lock_bh(&reg_lock);
	if (!next_free_user) {
		spin_unlock_bh(&reg_lock);
		return -EBUSY;
	}
	user_ptr = &users[next_free_user];
	*userid = next_free_user;
	next_free_user = user_ptr->next;
	user_ptr->next = -1; 
	spin_unlock_bh(&reg_lock);

	user_ptr->callback = cb;
	user_ptr->usr_handle = usr_handle;
	INIT_LIST_HEAD(&user_ptr->ports);
	atomic_inc(&tipc_user_count);
	
	if (cb && (tipc_mode != TIPC_NOT_RUNNING))
		k_signal((Handler)reg_callback, (unsigned long)user_ptr);
	return TIPC_OK;
}

/**
 * tipc_detach - deregister a TIPC user
 */

void tipc_detach(u32 userid)
{
	struct tipc_user *user_ptr;
	struct list_head ports_temp;
	struct user_port *up_ptr, *temp_up_ptr;

	if ((userid == 0) || (userid > MAX_USERID))
		return;

	spin_lock_bh(&reg_lock);
	if ((!users) || (users[userid].next >= 0)) {
		spin_unlock_bh(&reg_lock);
		return;
	}

	user_ptr = &users[userid];
        user_ptr->callback = NULL;              
	INIT_LIST_HEAD(&ports_temp);
        list_splice(&user_ptr->ports, &ports_temp);
	user_ptr->next = next_free_user;
	next_free_user = userid;
	spin_unlock_bh(&reg_lock);

	atomic_dec(&tipc_user_count);

        list_for_each_entry_safe(up_ptr, temp_up_ptr, &ports_temp, uport_list) {
		tipc_deleteport(up_ptr->ref);
	}
}

/**
 * reg_add_port - register a user's driver port
 */

int reg_add_port(struct user_port *up_ptr)
{
	struct tipc_user *user_ptr;

	if (up_ptr->user_ref == 0)
		return TIPC_OK;
	if (up_ptr->user_ref > MAX_USERID)
		return -EINVAL;
	if ((tipc_mode == TIPC_NOT_RUNNING) || !users )
		return -ENOPROTOOPT;

	spin_lock_bh(&reg_lock);
	user_ptr = &users[up_ptr->user_ref];
	list_add(&up_ptr->uport_list, &user_ptr->ports);
	spin_unlock_bh(&reg_lock);
	return TIPC_OK;
}

/**
 * reg_remove_port - deregister a user's driver port
 */

int reg_remove_port(struct user_port *up_ptr)
{
	if (up_ptr->user_ref == 0)
		return TIPC_OK;
	if (up_ptr->user_ref > MAX_USERID)
		return -EINVAL;
	if (!users )
		return -ENOPROTOOPT;

	spin_lock_bh(&reg_lock);
	list_del_init(&up_ptr->uport_list);
	spin_unlock_bh(&reg_lock);
	return TIPC_OK;
}

