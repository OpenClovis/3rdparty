/* ------------------------------------------------------------------------
 *
 * core.c
 *
 * Short description: TIPC mainline code
 *
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005-2006, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2003-01-29 by Abdallah Chatila
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: core.c,v 1.15 2006/06/22 20:08:04 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: core.c,v $
 *  Revision 1.15  2006/06/22 20:08:04  ajstephens
 *  Initial TIPC activation log message now includes TIPC version number
 *
 *  Revision 1.14  2006/04/25 19:30:00  ajstephens
 *  Added support for module versioning
 *
 *  Revision 1.13  2006/02/01 19:58:33  ajstephens
 *  Correct upper bound on max number of zones in tipc_init()
 *
 *  Revision 1.12  2005/10/31 21:09:31  ajstephens
 *  Reworked timer code to avoid deadlock on SMP systems; some link code cleanup
 *
 *  Revision 1.11  2005/10/28 11:33:37  perliden
 *  Resolved symbol name conflict with sock_init.
 *
 *  Revision 1.10  2005/09/06 08:02:05  perliden
 *  Removed use of deprecated macro EXPORT_SYMBOL_NOVERS
 *
 *  Revision 1.9  2005/08/25 15:51:40  ajstephens
 *  Major overhaul of configuration code; other bug fixes
 *
 *  Revision 1.8  2005/08/10 14:01:55  ajstephens
 *  Multicast & congestion handling changes
 *
 *  Revision 1.7  2005/08/05 20:35:48  ajstephens
 *  More major overhaul to socket code, plus other modifications
 *
 *  Revision 1.6  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.5  2005/06/07 15:10:59  ajstephens
 *  Cleaned up native port API; exported missing symbols for native API
 *
 *  Revision 1.4  2005/06/06 21:23:58  ajstephens
 *  More cleanup (fix max header size, add null checks, errno standardization, etc.)
 *
 *  Revision 1.3  2005/06/03 19:13:02  ajstephens
 *  More file content re-organization; also convert file EOLs back to Unix format
 *
 *  Revision 1.2  2005/06/03 14:18:31  ajstephens
 *  Move global user count to join rest of TIPC global variables
 *
 *  Revision 1.1  2005/06/01 19:13:28  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.24  2005/05/29 18:56:31  jonmaloy
 *  New topology subscription infrastructure
 *
 *  Revision 1.23  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.22  2005/05/04 14:14:29  ajstephens
 *  Replaced most "buf" routines by calls to "skb" routines
 *
 *  Revision 1.21  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.20  2005/04/05 17:21:01  jonmaloy
 *  Changed CONFIG_MAX_NODES to 255
 *
 *  Revision 1.19  2004/09/02 17:59:40  jonmaloy
 *  Standardizing informational printouts
 *
 *  Revision 1.12  2004/02/27 09:11:19  xfling
 *  make change for multicast to the base code
 *
 *  Revision 1.1  2003/05/16 20:45:42  telorb
 *  Checked in with epsi by lmcjoma
 *
 *
 *  Rev	Date		Rev by			Reason
 *  ---	----		------			------
 *  PA1	2003-01-29      lmcabda                 Created. [actually code shuffling]
 *
 * ------------------------------------------------------------------------
*/

#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/random.h>

#include "core.h"
#include "dbg.h"
#include "ref.h"
#include "net.h"
#include "user_reg.h"
#include "name_table.h"
#include "subscr.h"
#include "config.h"

int  eth_media_start(void);
void eth_media_stop(void);
int  handler_start(void);
void handler_stop(void);
int  socket_init(void);
void socket_stop(void);
int  netlink_start(void);
void netlink_stop(void);

#define TIPC_MOD_VER "1.5.12"

#ifndef CONFIG_TIPC_ZONES
#define CONFIG_TIPC_ZONES 3
#endif

#ifndef CONFIG_TIPC_CLUSTERS
#define CONFIG_TIPC_CLUSTERS 1
#endif

#ifndef CONFIG_TIPC_NODES
#define CONFIG_TIPC_NODES 255
#endif

#ifndef CONFIG_TIPC_SLAVE_NODES
#define CONFIG_TIPC_SLAVE_NODES 0
#endif

#ifndef CONFIG_TIPC_PORTS
#define CONFIG_TIPC_PORTS 8191
#endif

#ifndef CONFIG_TIPC_LOG
#define CONFIG_TIPC_LOG 0
#endif

/* global variables used by multiple sub-systems within TIPC */

int tipc_mode = TIPC_NOT_RUNNING;
int tipc_random;
atomic_t tipc_user_count = ATOMIC_INIT(0);

const char tipc_alphabet[] = 
	"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";

/* configurable TIPC parameters */

u32 tipc_own_addr;
int tipc_max_zones;
int tipc_max_clusters;
int tipc_max_nodes;
int tipc_max_slaves;
int tipc_max_ports;
int tipc_max_subscriptions;
int tipc_max_publications;
int tipc_net_id;
int tipc_remote_management;


int tipc_get_mode(void)
{
	return tipc_mode;
}

/**
 * stop_net - shut down TIPC networking sub-systems
 */

void stop_net(void)
{
	eth_media_stop();
	tipc_stop_net();
}

/**
 * start_net - start TIPC networking sub-systems
 */

int start_net(void)
{
	int res;

	if ((res = tipc_start_net()) ||
	    (res = eth_media_start())) {
		stop_net();
	}
	return res;
}

/**
 * stop_core - switch TIPC from SINGLE NODE to NOT RUNNING mode
 */

void stop_core(void)
{
	if (tipc_mode != TIPC_NODE_MODE)
		return;

	tipc_mode = TIPC_NOT_RUNNING;

	netlink_stop();
	handler_stop();
	cfg_stop();
	subscr_stop();
	reg_stop();
	nametbl_stop();
	ref_table_stop();
	socket_stop();
}

/**
 * start_core - switch TIPC from NOT RUNNING to SINGLE NODE mode
 */

int start_core(void)
{
	int res;

	if (tipc_mode != TIPC_NOT_RUNNING)
		return -ENOPROTOOPT;

	get_random_bytes(&tipc_random, sizeof(tipc_random));
	tipc_mode = TIPC_NODE_MODE;

	if ((res = handler_start()) || 
	    (res = ref_table_init(tipc_max_ports + tipc_max_subscriptions,
				  tipc_random)) ||
	    (res = reg_start()) ||
	    (res = nametbl_init()) ||
            (res = k_signal((Handler)subscr_start, 0)) ||
	    (res = k_signal((Handler)cfg_init, 0)) || 
	    (res = netlink_start()) ||
	    (res = socket_init())) {
		stop_core();
	}
	return res;
}


static int __init tipc_init(void)
{
	int res;

	log_reinit(CONFIG_TIPC_LOG);
	info("Activated (version " TIPC_MOD_VER 
	     " compiled " __DATE__ " " __TIME__ ")\n");

	tipc_own_addr = 0;
	tipc_remote_management = 1;
	tipc_max_publications = 10000;
	tipc_max_subscriptions = 2000;
	tipc_max_ports = delimit(CONFIG_TIPC_PORTS, 127, 65536);
	tipc_max_zones = delimit(CONFIG_TIPC_ZONES, 1, 255);
	tipc_max_clusters = delimit(CONFIG_TIPC_CLUSTERS, 1, 1);
	tipc_max_nodes = delimit(CONFIG_TIPC_NODES, 8, 2047);
	tipc_max_slaves = delimit(CONFIG_TIPC_SLAVE_NODES, 0, 2047);
	tipc_net_id = 4711;

	if ((res = start_core()))
		err("Unable to start in single node mode\n");
	else	
		info("Started in single node mode\n");
        return res;
}

static void __exit tipc_exit(void)
{
	stop_net();
	stop_core();
	info("Deactivated\n");
	log_stop();
}

module_init(tipc_init);
module_exit(tipc_exit);

MODULE_DESCRIPTION("TIPC: Transparent Inter Process Communication");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_VERSION(TIPC_MOD_VER);

/* Native TIPC API for kernel-space applications (see tipc.h) */

EXPORT_SYMBOL(tipc_attach);
EXPORT_SYMBOL(tipc_detach);
EXPORT_SYMBOL(tipc_get_addr);
EXPORT_SYMBOL(tipc_get_mode);
EXPORT_SYMBOL(tipc_createport);
EXPORT_SYMBOL(tipc_deleteport);
EXPORT_SYMBOL(tipc_ownidentity);
EXPORT_SYMBOL(tipc_portimportance);
EXPORT_SYMBOL(tipc_set_portimportance);
EXPORT_SYMBOL(tipc_portunreliable);
EXPORT_SYMBOL(tipc_set_portunreliable);
EXPORT_SYMBOL(tipc_portunreturnable);
EXPORT_SYMBOL(tipc_set_portunreturnable);
EXPORT_SYMBOL(tipc_publish);
EXPORT_SYMBOL(tipc_withdraw);
EXPORT_SYMBOL(tipc_connect2port);
EXPORT_SYMBOL(tipc_disconnect);
EXPORT_SYMBOL(tipc_shutdown);
EXPORT_SYMBOL(tipc_isconnected);
EXPORT_SYMBOL(tipc_peer);
EXPORT_SYMBOL(tipc_ref_valid);
EXPORT_SYMBOL(tipc_send);
EXPORT_SYMBOL(tipc_send_buf);
EXPORT_SYMBOL(tipc_send2name);
EXPORT_SYMBOL(tipc_forward2name);
EXPORT_SYMBOL(tipc_send_buf2name);
EXPORT_SYMBOL(tipc_forward_buf2name);
EXPORT_SYMBOL(tipc_send2port);
EXPORT_SYMBOL(tipc_forward2port);
EXPORT_SYMBOL(tipc_send_buf2port);
EXPORT_SYMBOL(tipc_forward_buf2port);
EXPORT_SYMBOL(tipc_multicast);
/* EXPORT_SYMBOL(tipc_multicast_buf); not available yet */
EXPORT_SYMBOL(tipc_ispublished);
EXPORT_SYMBOL(tipc_available_nodes);

/* TIPC API for external bearers (see tipc_bearer.h) */

EXPORT_SYMBOL(tipc_block_bearer);
EXPORT_SYMBOL(tipc_continue); 
EXPORT_SYMBOL(tipc_disable_bearer);
EXPORT_SYMBOL(tipc_enable_bearer);
EXPORT_SYMBOL(tipc_recv_msg);
EXPORT_SYMBOL(tipc_register_media); 

/* TIPC API for external APIs (see tipc_port.h) */

EXPORT_SYMBOL(tipc_createport_raw);
EXPORT_SYMBOL(tipc_set_msg_option);
EXPORT_SYMBOL(tipc_reject_msg);
EXPORT_SYMBOL(tipc_send_buf_fast);
EXPORT_SYMBOL(tipc_acknowledge);
EXPORT_SYMBOL(tipc_get_port);
EXPORT_SYMBOL(tipc_get_handle);

