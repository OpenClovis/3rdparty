/* ------------------------------------------------------------------------
 *
 * ref.h
 *
 * Short description: Include file for TIPC object registry code
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 1991-09-30 by Lars Svensson
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: ref.h,v 1.3 2005/10/04 14:10:41 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: ref.h,v $
 *  Revision 1.3  2005/10/04 14:10:41  ajstephens
 *  Corrected spinlock problems with network topology server.
 *
 *  Revision 1.2  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.1  2005/06/01 19:13:28  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.11  2005/05/29 18:56:32  jonmaloy
 *  New topology subscription infrastructure
 *
 *  Revision 1.10  2005/05/25 12:39:24  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.9  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.8  2005/03/08 19:03:07  jonmaloy
 *  Removed buf_safe_discard(). Made buf_discard() safe.
 *
 *  Revision 1.7  2004/06/22 01:42:48  jonmaloy
 *  Removed macro k_malloc and typedef tipc_net_addr_t
 *
 *  Revision 1.6  2004/06/16 17:29:33  jonmaloy
 *  Changed buf_safe_copy to take memory type arg
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	1991-09-30	Lars Svensson	Created.
 *  PA2	2000-09-30	Jon Maloy	Stripped and converted from C++
 *
 * ------------------------------------------------------------------------
 */

#ifndef _TIPC_REF_H
#define _TIPC_REF_H

/**
 * struct reference - TIPC object reference entry
 * @object: pointer to object associated with reference entry
 * @lock: spinlock controlling access to object
 * @data: reference value associated with object (or link to next unused entry)
 */
 
struct reference {
	void *object;
	spinlock_t lock;
	union {
		u32 next_plus_upper;
		u32 reference;
	} data;
};

/**
 * struct ref_table - table of TIPC object reference entries
 * @entries: pointer to array of reference entries
 * @index_mask: bitmask for array index portion of reference values
 * @first_free: array index of first unused object reference entry
 * @last_free: array index of last unused object reference entry
 */

struct ref_table {
	struct reference *entries;
	u32 index_mask;
	u32 first_free;
	u32 last_free;
};

extern struct ref_table ref_table;

int ref_table_init(u32 requested_size, u32 start);
void ref_table_stop(void);

u32 ref_acquire(void *object, spinlock_t **lock);
void ref_discard(u32 ref);


/**
 * ref_lock - lock referenced object and return pointer to it
 */

static inline void *ref_lock(u32 ref)
{
	if (likely(ref_table.entries)) {
		struct reference *r =
			&ref_table.entries[ref & ref_table.index_mask];

		spin_lock_bh(&r->lock);
		if (likely(r->data.reference == ref))
			return r->object;
		spin_unlock_bh(&r->lock);
	}
	return 0;
}

/**
 * ref_unlock - unlock referenced object 
 */

static inline void ref_unlock(u32 ref)
{
	if (likely(ref_table.entries)) {
		struct reference *r =
			&ref_table.entries[ref & ref_table.index_mask];

		if (likely(r->data.reference == ref))
			spin_unlock_bh(&r->lock);
		else
			err("ref_unlock() invoked using obsolete reference\n");
	}
}

/**
 * ref_deref - return pointer referenced object (without locking it)
 */

static inline void *ref_deref(u32 ref)
{
	if (likely(ref_table.entries)) {
		struct reference *r = 
			&ref_table.entries[ref & ref_table.index_mask];

		if (likely(r->data.reference == ref))
			return r->object;
	}
	return 0;
}

#endif
