/* ------------------------------------------------------------------------
 *
 * user_reg.h
 *
 * Short description: Include file for TIPC user registry code
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-09-30 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: user_reg.h,v 1.4 2005/09/08 21:38:01 jonmaloy Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: user_reg.h,v $
 *  Revision 1.4  2005/09/08 21:38:01  jonmaloy
 *  Fixed race condition between neighbour detection and tipc_stop_net
 *
 *  Revision 1.3  2005/06/16 12:49:31  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.2  2005/06/07 15:11:00  ajstephens
 *  Cleaned up native port API; exported missing symbols for native API
 *
 *  Revision 1.1  2005/06/01 19:13:28  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.11  2005/05/29 18:56:32  jonmaloy
 *  New topology subscription infrastructure
 *
 *  Revision 1.10  2005/05/25 12:39:24  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.9  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.8  2005/03/08 19:03:07  jonmaloy
 *  Removed buf_safe_discard(). Made buf_discard() safe.
 *
 *  Revision 1.7  2004/06/22 01:42:48  jonmaloy
 *  Removed macro k_malloc and typedef tipc_net_addr_t
 *
 *  Revision 1.6  2004/06/16 17:29:33  jonmaloy
 *  Changed buf_safe_copy to take memory type arg
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	2000-09-30	Jon Maloy	Created.
 *
 * ------------------------------------------------------------------------
 */

#ifndef _TIPC_USER_REG_H
#define _TIPC_USER_REG_H

#include "port.h"

int reg_start(void);
void reg_stop(void);

int reg_add_port(struct user_port *up_ptr);
int reg_remove_port(struct user_port *up_ptr);

#endif
