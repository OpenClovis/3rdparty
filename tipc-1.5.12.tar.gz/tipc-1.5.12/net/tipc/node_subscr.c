/* ------------------------------------------------------------------------
 *
 * node_subscr.c
 *
 * Short description: TIPC "node down" subscription handling
 * 
 * ------------------------------------------------------------------------
 * 
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 1995-05-30 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: node_subscr.c,v 1.13 2006/02/24 19:55:34 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: node_subscr.c,v $
 *  Revision 1.13  2006/02/24 19:55:34  ajstephens
 *  Enhanced & cleaned up TIPC system messages; fixed 2 obscure memory leaks
 *
 *  Revision 1.12  2006/02/16 17:56:31  ajstephens
 *  first phase of assert() cleanup
 *
 *  Revision 1.11  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.10  2005/11/04 16:49:10  ajstephens
 *  Added support for link statistics display (and reset)
 *
 *  Revision 1.9  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.8  2005/06/01 19:13:27  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.7  2005/05/25 12:39:23  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.6  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.5  2004/07/07 01:59:37  jonmaloy
 *  Fixed problems related to parallel link establish/shutdown
 *
 *  Revision 1.4  2004/06/22 01:42:48  jonmaloy
 *  Removed macro k_malloc and typedef tipc_net_addr_t
 *
 *  Revision 1.3  2004/05/10 21:07:57  markhaverkamp
 *  list_head updates to the node subscription data structures.
 *
 *  Revision 1.10  2003/05/16 20:49:55  telorb
 *  Checked in with epsi by lmcjoma
 *
 *  Revision 1.0 2003/02/02 03:51:00   lmcabda
 *  Released as an Open Source product under a BSD License
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	1995-05-30	Jon Maloy   Created as CoeccSubnetStateSubscriber.
 *  PA2	1995-09-22	euahafe
 *  PA3	1996-03-22	Jon Maloy   Rewritten and merged with struct nodeState
 *                                  Subscriber.
 *  PA4 2000-11-06      Jon Maloy   Converted from C++
 * ------------------------------------------------------------------------
*/

#include "core.h"
#include "dbg.h"
#include "node_subscr.h"
#include "node.h"
#include "addr.h"

/**
 * nodesub_subscribe - create "node down" subscription for specified node
 */

void nodesub_subscribe(struct node_subscr *node_sub, u32 addr, 
		       void *usr_handle, net_ev_handler handle_down)
{
	if (addr == tipc_own_addr) {
		node_sub->node = 0;
		return;
	}

	node_sub->node = node_find(addr);
	if (!node_sub->node) {
		warn("Node subscription rejected, unknown node 0x%x\n", addr);
		return;
	}
	node_sub->handle_node_down = handle_down;
	node_sub->usr_handle = usr_handle;

	node_lock(node_sub->node);
	list_add_tail(&node_sub->nodesub_list, &node_sub->node->nsub);
	node_unlock(node_sub->node);
}

/**
 * nodesub_unsubscribe - cancel "node down" subscription (if any)
 */

void nodesub_unsubscribe(struct node_subscr *node_sub)
{
	if (!node_sub->node)
		return;

	node_lock(node_sub->node);
	list_del_init(&node_sub->nodesub_list);
	node_unlock(node_sub->node);
}
