/* ------------------------------------------------------------------------
 *
 * port.h
 *
 * Short description: Include file for TIPC port code
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2004-2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 	1994-04-10 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: port.h,v 1.33 2005/12/07 17:53:44 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: port.h,v $
 *  Revision 1.33  2005/12/07 17:53:44  ajstephens
 *  First phase of multicast code cleanup
 *
 *  Revision 1.32  2005/11/28 22:02:00  ajstephens
 *  Eliminated risk of duplicate publication keys corrupting name table contents
 *
 *  Revision 1.31  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.30  2005/11/07 16:56:15  ajstephens
 *  Cleaned up port display output; prototyped port statistics support (but left disabled)
 *
 *  Revision 1.29  2005/10/12 19:11:36  ajstephens
 *  Reworked signal and timer code; eliminate risk of timers expiring after unloading
 *
 *  Revision 1.28  2005/09/23 12:40:50  ajstephens
 *  Fixed bugs with multicast fragementation and unneeded fragmentation
 *
 *  Revision 1.27  2005/08/25 15:51:40  ajstephens
 *  Major overhaul of configuration code; other bug fixes
 *
 *  Revision 1.26  2005/08/05 20:35:49  ajstephens
 *  More major overhaul to socket code, plus other modifications
 *
 *  Revision 1.25  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.24  2005/06/07 15:11:00  ajstephens
 *  Cleaned up native port API; exported missing symbols for native API
 *
 *  Revision 1.23  2005/06/06 21:23:58  ajstephens
 *  More cleanup (fix max header size, add null checks, errno standardization, etc.)
 *
 *  Revision 1.22  2005/06/03 19:13:03  ajstephens
 *  More file content re-organization; also convert file EOLs back to Unix format
 *
 *  Revision 1.21  2005/06/01 19:13:27  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.20  2005/05/25 12:39:24  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.19  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.18  2004/09/23 21:14:38  jonmaloy
 *  Redesigned multicast/broadcast functionality
 *
 *  Revision 1.17  2004/08/19 14:54:06  ajstephens
 *  Fix function prototype inconsistencies.
 *
 *  Revision 1.16  2004/07/01 03:22:26  xfling
 *  resovle congestion problem for replicated multicast.
 *  add mc_head in port struct.
 *
 *  Revision 1.14  2004/06/21 20:13:56  markhaverkamp
 *  Use port_deref instead of port_lock in tipc_multicast.  This avoids
 *  a spinlock deadlock and the lock isn't required.
 *
 *  Revision 1.8  2003/09/24 14:56:44  telorb
 *  Checked in with epsi by lmcjoma
 *
 *  Revision 1.6 2003/02/02 03:51:00   lmcabda
 *  Released as an Open Source product under a BSD License
 *
 *  Revision 1.5  2001/12/06 15:58:30  uabjon
 *  Checked in with epsi
 *
 *  Revision 1.21  2000/08/09 14:32:51  qabpea
 *  Checked in with epsi
 *
 *  Revision 1.19  2000/04/07 13:02:26  uablrek
 *  Use syslog
 *
 *  PA1	 1994-04-10	Jon Maloy	Created.
 *  PA2	 1995-10-19	Jon Maloy	Rewritten for BS2.
 *  PA3	 1996-02-23	Jon Maloy	Simplified.
 *  1.13 1998-04-28	uablrek `Importance' re-introduced.
 *  1.16 1998-07-15	uablrek The ShadowDicosPort size expanded.
 *  PB1  2000-11-13     Jon Maloy       Converted from C++
 * ------------------------------------------------------------------------
*/

#ifndef _TIPC_PORT_H
#define _TIPC_PORT_H

#include <tipc_port.h>
#include "ref.h"
#include "net.h"
#include "msg.h"
#include "dbg.h"
#include "node_subscr.h"

/**
 * struct user_port - TIPC user port (used with native API)
 * @user_ref: id of user who created user port
 * @usr_handle: user-specified field
 * @ref: object reference to associated TIPC port
 * <various callback routines>
 * @uport_list: adjacent user ports in list of ports held by user
 */
 
struct user_port {
	u32 user_ref;
	void *usr_handle; 
	u32 ref;
	tipc_msg_err_event err_cb; 
	tipc_named_msg_err_event named_err_cb; 
	tipc_conn_shutdown_event conn_err_cb; 
	tipc_msg_event msg_cb; 
	tipc_named_msg_event named_msg_cb; 
	tipc_conn_msg_event conn_msg_cb; 
	tipc_continue_event continue_event_cb;
	struct list_head uport_list;
};

/**
 * struct port - TIPC port structure
 * @publ: TIPC port info available to privileged users
 * @port_list: adjacent ports in TIPC's global list of ports
 * @dispatcher: ptr to routine which handles received messages
 * @wakeup: ptr to routine to call when port is no longer congested
 * @user_port: ptr to user port associated with port (if any)
 * @wait_list: adjacent ports in list of ports waiting on link congestion
 * @congested_link: ptr to congested link port is waiting on
 * @waiting_pkts:
 * @sent:
 * @acked:
 * @publications: list of publications for port
 * @pub_count: total # of publications port has made during its lifetime
 * @max_pkt: maximum packet size "hint" used when building messages sent by port
 * @probing_state:
 * @probing_interval:
 * @last_in_seqno:
 * @timer_ref:
 * @subscription: "node down" subscription used to terminate failed connections
 */

struct port {
	struct tipc_port publ;
	struct list_head port_list;
	u32 (*dispatcher)(struct tipc_port *, struct sk_buff *);
	void (*wakeup)(struct tipc_port *);
	struct user_port *user_port;
	struct list_head wait_list;
	struct link *congested_link;
	u32 waiting_pkts;
	u32 sent;
	u32 acked;
	struct list_head publications;
	u32 pub_count;
	u32 max_pkt;
	u32 probing_state;
	u32 probing_interval;
	u32 last_in_seqno;
	struct timer_list timer;
	struct node_subscr subscription;
};

extern spinlock_t port_list_lock;
struct port_list;

int port_recv_sections(struct port *p_ptr, u32 num_sect, 
		       struct iovec const *msg_sect);
int port_reject_sections(struct port *p_ptr, struct tipc_msg *hdr,
			 struct iovec const *msg_sect, u32 num_sect,
			 int err);
struct sk_buff *port_get_ports(void);
struct sk_buff *port_show_stats(const void *req_tlv_area, int req_tlv_space);
void port_recv_proto_msg(struct sk_buff *buf);
void port_recv_mcast(struct sk_buff *buf, struct port_list *dp);
void port_reinit(void);

/**
 * port_lock - lock port instance referred to and return its pointer
 */

static inline struct port *port_lock(u32 ref)
{
	return (struct port *)ref_lock(ref);
}

/** 
 * port_unlock - unlock a port instance
 * 
 * Can use pointer instead of ref_unlock() since port is already locked.
 */

static inline void port_unlock(struct port *p_ptr)
{
	spin_unlock_bh(p_ptr->publ.lock);
}

static inline struct port* port_deref(u32 ref)
{
	return (struct port *)ref_deref(ref);
}

static inline u32 peer_port(struct port *p_ptr)
{
	return msg_destport(&p_ptr->publ.phdr);
}

static inline u32 peer_node(struct port *p_ptr)
{
	return msg_destnode(&p_ptr->publ.phdr);
}

static inline int port_congested(struct port *p_ptr)
{
	return((p_ptr->sent - p_ptr->acked) >= (TIPC_FLOW_CONTROL_WIN * 2));
}

/** 
 * port_recv_msg - receive message from lower layer and deliver to port user
 */

static inline int port_recv_msg(struct sk_buff *buf)
{
	struct port *p_ptr;
	struct tipc_msg *msg = buf_msg(buf);
	u32 destport = msg_destport(msg);
	u32 dsz = msg_data_sz(msg);
	u32 err;
	
	/* forward unresolved named message */
	if (unlikely(!destport)) {
		net_route_msg(buf);
		return dsz;
	}

	/* validate destination & pass to port, otherwise reject message */
	p_ptr = port_lock(destport);
	if (likely(p_ptr)) {
		if (likely(p_ptr->publ.connected)) {
			if ((unlikely(msg_origport(msg) != peer_port(p_ptr))) ||
			    (unlikely(msg_orignode(msg) != peer_node(p_ptr))) ||
			    (unlikely(!msg_connected(msg)))) {
				err = TIPC_ERR_NO_PORT;
				port_unlock(p_ptr);
				goto reject;
			}
		}
		err = p_ptr->dispatcher(&p_ptr->publ, buf);
		port_unlock(p_ptr);
		if (likely(!err))
			return dsz;
	} else {
		err = TIPC_ERR_NO_PORT;
	}
reject:
	dbg("port->rejecting, err = %x..\n",err);
	return tipc_reject_msg(buf, err);
}

#endif
