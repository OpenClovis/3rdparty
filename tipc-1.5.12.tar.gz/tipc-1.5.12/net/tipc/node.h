/* ------------------------------------------------------------------------
 *
 * node.h
 *
 * Short description: Include file for TIPC node management routines
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-05-04 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: node.h,v 1.26 2006/04/13 14:21:38 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: node.h,v $
 *  Revision 1.26  2006/04/13 14:21:38  ajstephens
 *  Fixed link switchover bugs relating to use of standby links
 *
 *  Revision 1.25  2005/12/13 20:39:12  ajstephens
 *  Final phase of broadcast code cleanup
 *
 *  Revision 1.24  2005/12/08 18:03:40  ajstephens
 *  Increased number of reserved types from 8 to 64
 *
 *  Revision 1.23  2005/12/07 17:53:44  ajstephens
 *  First phase of multicast code cleanup
 *
 *  Revision 1.22  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.21  2005/08/25 15:51:40  ajstephens
 *  Major overhaul of configuration code; other bug fixes
 *
 *  Revision 1.20  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.19  2005/06/01 19:13:27  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.18  2005/05/25 12:39:23  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.17  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.16  2005/02/04 00:42:28  jonmaloy
 *  Broadcasting broadcast NACKs
 *
 *  Revision 1.15  2005/01/12 20:31:57  jonmaloy
 *  New multicast/broadcast code is working
 *
 *  Revision 1.14  2004/09/23 21:14:38  jonmaloy
 *  Redesigned multicast/broadcast functionality
 *
 *  Revision 1.9  2004/05/10 21:07:57  markhaverkamp
 *  list_head updates to the node subscription data structures.
 *
 *  Revision 1.7  2004/02/27 09:11:20  xfling
 *  make change for multicast to the base code
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	2000-05-04	Jon Maloy	Created.
 *  PA1	2000-11-15	Jon Maloy	Converted from C++
 *
 * ------------------------------------------------------------------------
*/

#ifndef _TIPC_NODE_H
#define _TIPC_NODE_H

#include "node_subscr.h"
#include "addr.h"
#include "cluster.h"
#include "bearer.h"

/**
 * struct node - TIPC node structure
 * @addr: network address of node
 * @lock: spinlock governing access to structure
 * @owner: pointer to cluster that node belongs to
 * @next: pointer to next node in sorted list of cluster's nodes
 * @nsub: list of "node down" subscriptions monitoring node
 * @active_links: pointers to active links to node
 * @links: pointers to all links to node
 * @working_links: number of working links to node (both active and standby)
 * @link_cnt: number of links to node
 * @permit_changeover: non-zero if node has redundant links to this system
 * @routers: bitmap (used for multicluster communication)
 * @last_router: (used for multicluster communication)
 * @bclink: broadcast-related info
 *    @supported: non-zero if node supports TIPC b'cast capability
 *    @acked: sequence # of last outbound b'cast message acknowledged by node
 *    @last_in: sequence # of last in-sequence b'cast message received from node
 *    @gap_after: sequence # of last message not requiring a NAK request
 *    @gap_to: sequence # of last message requiring a NAK request
 *    @nack_sync: counter that determines when NAK requests should be sent
 *    @deferred_head: oldest OOS b'cast message received from node
 *    @deferred_tail: newest OOS b'cast message received from node
 *    @defragm: list of partially reassembled b'cast message fragments from node
 */
 
struct node {
	u32 addr;
	spinlock_t lock;
	struct cluster *owner;
	struct node *next;
	struct list_head nsub;
	struct link *active_links[2];
	struct link *links[MAX_BEARERS];
	int link_cnt;
	int working_links;
	int permit_changeover;
	u32 routers[512/32];
	int last_router;
	struct {
		int supported;
		u32 acked;
		u32 last_in;
		u32 gap_after; 
		u32 gap_to; 
		u32 nack_sync;
		struct sk_buff *deferred_head;
		struct sk_buff *deferred_tail;
		struct sk_buff *defragm;
	} bclink;
};

extern struct node *nodes;
extern u32 tipc_own_tag;

struct node *node_create(u32 addr);
void node_delete(struct node *n_ptr);
struct node *node_attach_link(struct link *l_ptr);
void node_detach_link(struct node *n_ptr, struct link *l_ptr);
void node_link_down(struct node *n_ptr, struct link *l_ptr);
void node_link_up(struct node *n_ptr, struct link *l_ptr);
int node_has_active_links(struct node *n_ptr);
int node_has_redundant_links(struct node *n_ptr);
u32 node_select_router(struct node *n_ptr, u32 ref);
struct node *node_select_next_hop(u32 addr, u32 selector);
int node_is_up(struct node *n_ptr);
void node_add_router(struct node *n_ptr, u32 router);
void node_remove_router(struct node *n_ptr, u32 router);
struct sk_buff *node_get_links(const void *req_tlv_area, int req_tlv_space);
struct sk_buff *node_get_nodes(const void *req_tlv_area, int req_tlv_space);

static inline struct node *node_find(u32 addr)
{
	if (likely(in_own_cluster(addr)))
		return local_nodes[tipc_node(addr)];
	else if (addr_domain_valid(addr)) {
		struct cluster *c_ptr = cluster_find(addr);

		if (c_ptr)
			return c_ptr->nodes[tipc_node(addr)];
	}
	return 0;
}

static inline struct node *node_select(u32 addr, u32 selector)
{
	if (likely(in_own_cluster(addr)))
		return local_nodes[tipc_node(addr)];
	return node_select_next_hop(addr, selector);
}

static inline void node_lock(struct node *n_ptr)
{
	spin_lock_bh(&n_ptr->lock);
}

static inline void node_unlock(struct node *n_ptr)
{
	spin_unlock_bh(&n_ptr->lock);
}

#endif
