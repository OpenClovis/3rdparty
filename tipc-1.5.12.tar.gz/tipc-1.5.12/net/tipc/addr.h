/* ------------------------------------------------------------------------
 *
 * addr.h
 *
 * Short description: Include file for TIPC address utility routines
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2004-2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-09-30 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: addr.h,v 1.12 2005/12/08 18:03:38 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: addr.h,v $
 *  Revision 1.12  2005/12/08 18:03:38  ajstephens
 *  Increased number of reserved types from 8 to 64
 *
 *  Revision 1.11  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.10  2005/06/16 12:49:29  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.9  2005/06/01 19:13:26  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.8  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.7  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.6  2004/07/29 19:44:00  ajstephens
 *  Don't allow non-void routines to exit without return value.
 *
 *  Revision 1.5  2004/06/22 01:42:47  jonmaloy
 *  Removed macro k_malloc and typedef tipc_net_addr_t
 *
 *  Revision 1.4  2004/06/09 23:14:46  jonmaloy
 *  Added dynamic module configuration support
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	2000-09-30	Jon Maloy	Created.
 *
 * ------------------------------------------------------------------------
*/
#ifndef _TIPC_ADDR_H
#define _TIPC_ADDR_H

static inline u32 own_node(void)
{
	return tipc_node(tipc_own_addr);
}

static inline u32 own_cluster(void)
{
	return tipc_cluster(tipc_own_addr);
}

static inline u32 own_zone(void)
{
	return tipc_zone(tipc_own_addr);
}

static inline int in_own_cluster(u32 addr)
{
	return !((addr ^ tipc_own_addr) >> 12);
}

static inline int in_own_zone(u32 addr)
{
	return !((addr ^ tipc_own_addr) >> 24);
}

static inline int is_slave(u32 addr)
{
	return addr & 0x800;
}

static inline int may_route(u32 addr)
{
	return(addr ^ tipc_own_addr) >> 11;
}

static inline int in_scope(u32 domain, u32 addr)
{
	if (!domain || (domain == addr))
		return 1;
	if (domain == (addr & 0xfffff000u)) /* domain <Z.C.0> */
		return 1;
	if (domain == (addr & 0xff000000u)) /* domain <Z.0.0> */
		return 1;
	return 0;
}

/**
 * addr_scope - convert message lookup domain to equivalent 2-bit scope value
 */

static inline int addr_scope(u32 domain)
{
	if (likely(!domain))
		return TIPC_ZONE_SCOPE;
	if (tipc_node(domain))
		return TIPC_NODE_SCOPE;
	if (tipc_cluster(domain))
		return TIPC_CLUSTER_SCOPE;
	return TIPC_ZONE_SCOPE;
}

/**
 * addr_domain - convert 2-bit scope value to equivalent message lookup domain
 *  
 * Needed when address of a named message must be looked up a second time 
 * after a network hop.
 */

static inline int addr_domain(int sc)
{
	if (likely(sc == TIPC_NODE_SCOPE))
		return tipc_own_addr;
	if (sc == TIPC_CLUSTER_SCOPE)
		return tipc_addr(tipc_zone(tipc_own_addr),
				 tipc_cluster(tipc_own_addr), 0);
	return tipc_addr(tipc_zone(tipc_own_addr), 0, 0);
}

static inline char *addr_string_fill(char *string, u32 addr)
{
	snprintf(string, 16, "<%u.%u.%u>",
		 tipc_zone(addr), tipc_cluster(addr), tipc_node(addr));
	return string;
}

int addr_domain_valid(u32);
int addr_node_valid(u32 addr);

#endif
