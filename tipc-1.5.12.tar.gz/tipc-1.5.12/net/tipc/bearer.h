/* ------------------------------------------------------------------------
 *
 * bearer.h
 *
 * Short description: Include file for TIPC bearer code
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 1996-10-30 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: bearer.h,v 1.14 2005/12/14 18:18:49 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: bearer.h,v $
 *  Revision 1.14  2005/12/14 18:18:49  ajstephens
 *  Eliminated non-standard TIPC_CONGESTION error code; minor b'cast fixes
 *
 *  Revision 1.13  2005/12/12 21:40:00  ajstephens
 *  Second phase of multicast code cleanup; also enhanced bearer priority support
 *
 *  Revision 1.12  2005/12/07 17:53:42  ajstephens
 *  First phase of multicast code cleanup
 *
 *  Revision 1.11  2005/11/30 15:02:31  ajstephens
 *  Removed obsoleted debugging code
 *
 *  Revision 1.10  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.9  2005/11/09 19:35:32  jonmaloy
 *  Added MTU negotiation and stale check in link protocol
 *
 *  Revision 1.8  2005/10/12 19:11:36  ajstephens
 *  Reworked signal and timer code; eliminate risk of timers expiring after unloading
 *
 *  Revision 1.7  2005/08/30 14:14:44  ajstephens
 *  Final changes prior to TIPC 1.5.4 release
 *
 *  Revision 1.6  2005/08/25 15:51:40  ajstephens
 *  Major overhaul of configuration code; other bug fixes
 *
 *  Revision 1.5  2005/08/05 20:35:48  ajstephens
 *  More major overhaul to socket code, plus other modifications
 *
 *  Revision 1.4  2005/06/16 12:49:29  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.3  2005/06/06 21:23:58  ajstephens
 *  More cleanup (fix max header size, add null checks, errno standardization, etc.)
 *
 *  Revision 1.2  2005/06/03 19:13:02  ajstephens
 *  More file content re-organization; also convert file EOLs back to Unix format
 *
 *  Revision 1.1  2005/06/01 19:13:28  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.15  2005/06/01 13:04:01  ajstephens
 *  Link/bearer/media name rework; continued cleanup
 *
 *  Revision 1.14  2005/05/25 20:23:59  ajstephens
 *  Revised bearer and media name handling
 *
 *  Revision 1.13  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.12  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.11  2005/01/17 21:58:17  jonmaloy
 *  Improved multicast/broadcast handling
 *
 *  Revision 1.10  2004/09/23 21:14:38  jonmaloy
 *  Redesigned multicast/broadcast functionality
 *
 *  Revision 1.9  2004/06/23 21:52:28  jonmaloy
 *  Corrected erroneous return value from bearer_congested
 *
 *  Revision 1.6  2004/05/06 15:35:31  markhaverkamp
 *  Update structures to use statndard list_head structures and macros:
 *  bearer, link, subscr_data, and manager.
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	1996-10-30	Jon Maloy	Created
 *  PA2	2000-10-20	Jon Maloy	Converted from C++ 
 *
 * ------------------------------------------------------------------------
*/
#ifndef _TIPC_BEARER_H
#define _TIPC_BEARER_H

#include <tipc_bearer.h>
#include "bcast.h"

#define MAX_BEARERS 8
#define MAX_MEDIA 4


/**
 * struct media - TIPC media information available to internal users
 * @send_msg: routine which handles buffer transmission
 * @enable_bearer: routine which enables a bearer
 * @disable_bearer: routine which disables a bearer
 * @addr2str: routine which converts bearer's address to string form
 * @bcast_addr: media address used in broadcasting
 * @bcast: non-zero if media supports broadcasting [currently mandatory]
 * @priority: default link (and bearer) priority
 * @tolerance: default time (in ms) before declaring link failure
 * @window: default window (in packets) before declaring link congestion
 * @type_id: TIPC media identifier [defined in tipc_bearer.h]
 * @name: media name
 */
 
struct media {
	int (*send_msg)(struct sk_buff *buf, 
			struct tipc_bearer *b_ptr,
			struct tipc_media_addr *dest);
	int (*enable_bearer)(struct tipc_bearer *b_ptr);
	void (*disable_bearer)(struct tipc_bearer *b_ptr);
	char *(*addr2str)(struct tipc_media_addr *a, 
			  char *str_buf, int str_size);
	struct tipc_media_addr bcast_addr;
	int bcast;
	u32 priority;
	u32 tolerance;
	u32 window;
	u32 type_id;
	char name[MAX_MEDIA_NAME];
};

/**
 * struct bearer - TIPC bearer information available to internal users
 * @publ: bearer information available to privileged users
 * @media: ptr to media structure associated with bearer
 * @priority: default link priority for bearer
 * @detect_scope: network address mask used during automatic link creation
 * @identity: array index of this bearer within TIPC bearer array
 * @link_req: ptr to (optional) structure making periodic link setup requests
 * @links: list of non-congested links associated with bearer
 * @cong_links: list of congested links associated with bearer
 * @continue_count: # of times bearer has resumed after congestion or blocking
 * @active: non-zero if bearer structure is represents a bearer
 * @net_plane: network plane ('A' through 'H') currently associated with bearer
 * @nodes: indicates which nodes in cluster can be reached through bearer
 */
 
struct bearer {
	struct tipc_bearer publ;
	struct media *media;
	u32 priority;
	u32 detect_scope;
	u32 identity;
	struct link_req *link_req;
	struct list_head links;
	struct list_head cong_links;
	u32 continue_count;
	int active;
	char net_plane;
	struct node_map nodes;
};

struct bearer_name {
	char media_name[MAX_MEDIA_NAME];
	char if_name[MAX_IF_NAME];
};

struct link;

extern struct bearer *bearers;

void media_addr_printf(struct print_buf *pb, struct tipc_media_addr *a);
struct sk_buff *media_get_names(void);

struct sk_buff *bearer_get_names(void);
void bearer_add_dest(struct bearer *b_ptr, u32 dest);
void bearer_remove_dest(struct bearer *b_ptr, u32 dest);
void bearer_schedule(struct bearer *b_ptr, struct link *l_ptr);
struct bearer *bearer_find_interface(const char *if_name);
int bearer_resolve_congestion(struct bearer *b_ptr, struct link *l_ptr);
int bearer_init(void);
void bearer_stop(void);
int bearer_broadcast(struct sk_buff *buf, struct tipc_bearer *b_ptr,
		     struct tipc_media_addr *dest);
void bearer_lock_push(struct bearer *b_ptr);


/**
 * bearer_send- sends buffer to destination over bearer 
 * 
 * Returns true (1) if successful, or false (0) if unable to send
 * 
 * IMPORTANT:
 * The media send routine must not alter the buffer being passed in
 * as it may be needed for later retransmission!
 * 
 * If the media send routine returns a non-zero value (indicating that 
 * it was unable to send the buffer), it must:
 *   1) mark the bearer as blocked,
 *   2) call tipc_continue() once the bearer is able to send again.
 * Media types that are unable to meet these two critera must ensure their
 * send routine always returns success -- even if the buffer was not sent --
 * and let TIPC's link code deal with the undelivered message. 
 */

static inline int bearer_send(struct bearer *b_ptr, struct sk_buff *buf,
			      struct tipc_media_addr *dest)
{
	return !b_ptr->media->send_msg(buf, &b_ptr->publ, dest);
}

/**
 * bearer_congested - determines if bearer is currently congested
 */

static inline int bearer_congested(struct bearer *b_ptr, struct link *l_ptr)
{
	if (unlikely(b_ptr->publ.blocked))
		return 1;
	if (likely(list_empty(&b_ptr->cong_links)))
		return 0;
	return !bearer_resolve_congestion(b_ptr, l_ptr);
}

#endif
