/* ------------------------------------------------------------------------
 *
 * name_table.h
 *
 * Short description: Include file for TIPC name table code
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2004-2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-10-27 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: name_table.h,v 1.21 2005/12/12 21:40:00 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: name_table.h,v $
 *  Revision 1.21  2005/12/12 21:40:00  ajstephens
 *  Second phase of multicast code cleanup; also enhanced bearer priority support
 *
 *  Revision 1.20  2005/12/08 18:03:40  ajstephens
 *  Increased number of reserved types from 8 to 64
 *
 *  Revision 1.19  2005/12/07 17:53:42  ajstephens
 *  First phase of multicast code cleanup
 *
 *  Revision 1.18  2005/11/28 22:02:00  ajstephens
 *  Eliminated risk of duplicate publication keys corrupting name table contents
 *
 *  Revision 1.17  2005/08/25 15:51:40  ajstephens
 *  Major overhaul of configuration code; other bug fixes
 *
 *  Revision 1.16  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.15  2005/06/01 19:13:27  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.14  2005/06/01 13:04:01  ajstephens
 *  Link/bearer/media name rework; continued cleanup
 *
 *  Revision 1.13  2005/05/29 18:56:32  jonmaloy
 *  New topology subscription infrastructure
 *
 *  Revision 1.12  2005/05/25 12:39:23  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.11  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.10  2005/01/24 19:21:57  jonmaloy
 *  Fixed some mcast related bugs
 *
 *  Revision 1.9  2005/01/17 21:58:18  jonmaloy
 *  Improved multicast/broadcast handling
 *
 *  Revision 1.8  2004/09/23 21:14:38  jonmaloy
 *  Redesigned multicast/broadcast functionality
 *
 *  Revision 1.7  2004/09/09 18:46:32  ajstephens
 *  Enhance name table display capability
 *
 *  Revision 1.4  2004/05/06 22:31:06  markhaverkamp
 *  Update more data structures to use list_head macros:
 *  port and publication.
 *
 *  Rev Date       Rev by  Reason
 *  --- ----       ------  ------
 *
 *  PA1	2000-10-27	Jon Maloy	Created.
 *
 * ------------------------------------------------------------------------
*/

#ifndef _TIPC_NAME_TABLE_H
#define _TIPC_NAME_TABLE_H

#include "node_subscr.h"

struct subscription;
struct port_list;

/*
 * TIPC name types reserved for internal TIPC use (both current and planned)
 */

#define TIPC_ZM_SRV 3  		/* zone master service name type */


/**
 * struct publication - info about a published (name or) name sequence
 * @type: name sequence type
 * @lower: name sequence lower bound
 * @upper: name sequence upper bound
 * @scope: scope of publication
 * @node: network address of publishing port's node
 * @ref: publishing port
 * @key: publication key
 * @subscr: subscription to "node down" event (for off-node publications only)
 * @local_list: adjacent entries in list of publications made by this node
 * @pport_list: adjacent entries in list of publications made by this port
 * @node_list: next matching name seq publication with >= node scope
 * @cluster_list: next matching name seq publication with >= cluster scope
 * @zone_list: next matching name seq publication with >= zone scope
 * 
 * Note that the node list, cluster list, and zone list are circular lists.
 */

struct publication {
	u32 type;
	u32 lower;
	u32 upper;
	u32 scope;
	u32 node;
	u32 ref;
	u32 key;
	struct node_subscr subscr;
	struct list_head local_list;
	struct list_head pport_list;
	struct publication *node_list_next;
	struct publication *cluster_list_next;
	struct publication *zone_list_next;
};


extern rwlock_t nametbl_lock;

struct sk_buff *nametbl_get(const void *req_tlv_area, int req_tlv_space);
u32 nametbl_translate(u32 type, u32 instance, u32 *node);
int nametbl_mc_translate(u32 type, u32 lower, u32 upper, u32 limit, 
			 struct port_list *dports);
int nametbl_publish_rsv(u32 ref, unsigned int scope, 
			struct tipc_name_seq const *seq);
struct publication *nametbl_publish(u32 type, u32 lower, u32 upper,
				    u32 scope, u32 port_ref, u32 key);
int nametbl_withdraw(u32 type, u32 lower, u32 ref, u32 key);
struct publication *nametbl_insert_publ(u32 type, u32 lower, u32 upper,
					u32 scope, u32 node, u32 ref, u32 key);
struct publication *nametbl_remove_publ(u32 type, u32 lower, 
					u32 node, u32 ref, u32 key);
void nametbl_subscribe(struct subscription *s);
void nametbl_unsubscribe(struct subscription *s);
int nametbl_init(void);
void nametbl_stop(void);

#endif
