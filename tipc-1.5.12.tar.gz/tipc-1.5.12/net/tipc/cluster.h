/* ------------------------------------------------------------------------
 *
 * cluster.h
 *
 * Short description: Include file for TIPC cluster management routines
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-05-04 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: cluster.h,v 1.13 2005/12/07 17:53:42 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: cluster.h,v $
 *  Revision 1.13  2005/12/07 17:53:42  ajstephens
 *  First phase of multicast code cleanup
 *
 *  Revision 1.12  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.11  2005/06/01 19:13:26  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.10  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.9  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.8  2004/09/23 21:14:38  jonmaloy
 *  Redesigned multicast/broadcast functionality
 *
 *  Revision 1.7  2004/06/22 01:42:47  jonmaloy
 *  Removed macro k_malloc and typedef tipc_net_addr_t
 *
 *  Revision 1.6  2004/06/09 23:14:46  jonmaloy
 *  Added dynamic module configuration support
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	2000-05-04	Jon Maloy	Created.
 *  PA1	2000-11-15	Jon Maloy	Converted from C++.
 *
 * ------------------------------------------------------------------------
 */

#ifndef _TIPC_CLUSTER_H
#define _TIPC_CLUSTER_H

#include "addr.h"
#include "zone.h"

#define LOWEST_SLAVE  2048u

/**
 * struct cluster - TIPC cluster structure
 * @addr: network address of cluster
 * @owner: pointer to zone that cluster belongs to
 * @nodes: array of pointers to all nodes within cluster
 * @highest_node: id of highest numbered node within cluster
 * @highest_slave: (used for secondary node support)
 */
 
struct cluster {
	u32 addr;
	struct _zone *owner;
	struct node **nodes;
	u32 highest_node;
	u32 highest_slave;
};


extern struct node **local_nodes;
extern u32 highest_allowed_slave;
extern struct node_map cluster_bcast_nodes;

void cluster_remove_as_router(struct cluster *c_ptr, u32 router);
void cluster_send_ext_routes(struct cluster *c_ptr, u32 dest);
struct node *cluster_select_node(struct cluster *c_ptr, u32 selector);
u32 cluster_select_router(struct cluster *c_ptr, u32 ref);
void cluster_recv_routing_table(struct sk_buff *buf);
struct cluster *cluster_create(u32 addr);
void cluster_delete(struct cluster *c_ptr);
void cluster_attach_node(struct cluster *c_ptr, struct node *n_ptr);
void cluster_send_slave_routes(struct cluster *c_ptr, u32 dest);
void cluster_broadcast(struct sk_buff *buf);
int cluster_init(void);
u32 cluster_next_node(struct cluster *c_ptr, u32 addr);
void cluster_bcast_new_route(struct cluster *c_ptr, u32 dest, u32 lo, u32 hi);
void cluster_send_local_routes(struct cluster *c_ptr, u32 dest);
void cluster_bcast_lost_route(struct cluster *c_ptr, u32 dest, u32 lo, u32 hi);

static inline struct cluster *cluster_find(u32 addr)
{
	struct _zone *z_ptr = zone_find(addr);

	if (z_ptr)
		return z_ptr->clusters[1];
	return 0;
}

#endif
