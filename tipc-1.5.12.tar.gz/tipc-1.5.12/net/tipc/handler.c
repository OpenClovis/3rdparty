/* ------------------------------------------------------------------------
 *
 * handler.c
 *
 * Short description: TIPC signal handling
 * 
 * ------------------------------------------------------------------------
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 2000-09-02 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: handler.c,v 1.19 2005/11/16 20:32:00 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: handler.c,v $
 *  Revision 1.19  2005/11/16 20:32:00  ajstephens
 *  Revised max packet handling, plus additional cleanup
 *
 *  Revision 1.18  2005/10/12 19:11:36  ajstephens
 *  Reworked signal and timer code; eliminate risk of timers expiring after unloading
 *
 *  Revision 1.17  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.16  2005/06/06 21:23:58  ajstephens
 *  More cleanup (fix max header size, add null checks, errno standardization, etc.)
 *
 *  Revision 1.15  2005/06/01 19:13:26  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.14  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.13  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.12  2004/07/07 01:59:37  jonmaloy
 *  Fixed problems related to parallel link establish/shutdown
 *
 *  Revision 1.11  2004/06/09 23:14:46  jonmaloy
 *  Added dynamic module configuration support
 *
 *  Revision 1.10  2004/05/12 23:06:00  jonmaloy
 *  Removed k_time_ms()
 *
 *  Rev	Date		Rev by			Reason
 *  ---	----		------			------
 *
 *  PA1	2000-09-11	Jon Maloy		Created.
 *      2001-08-08	Abdallah Chatila 	Portation to Linux-2.4.7
 *	2004-02-11      Jon Maloy               Changed to dynamic memory handling, as
 *                                              developed by Mark Haverkamp (markh@osdl.org)
 *
 * -----------------------------------------------------------------------
*/

#include "core.h"


struct queue_item {
	struct list_head next_signal;
	void (*handler) (unsigned long);
	unsigned long data;
};

static kmem_cache_t *tipc_queue_item_cache;
static struct list_head signal_queue_head;
static spinlock_t qitem_lock = SPIN_LOCK_UNLOCKED;
static int handler_enabled = 0;

static void process_signal_queue(unsigned long dummy);

static DECLARE_TASKLET_DISABLED(tipc_tasklet, process_signal_queue, 0);


unsigned int k_signal(Handler routine, unsigned long argument)
{
	struct queue_item *item;

	if (!handler_enabled) {
		err("Signal request ignored by handler\n");
		return -ENOPROTOOPT;
	}

	spin_lock_bh(&qitem_lock);
	item = kmem_cache_alloc(tipc_queue_item_cache, GFP_ATOMIC);
	if (!item) {
		err("Signal queue out of memory\n");
		spin_unlock_bh(&qitem_lock);
		return -ENOMEM;
	}
	item->handler = routine;
	item->data = argument;
	list_add_tail(&item->next_signal, &signal_queue_head);
	spin_unlock_bh(&qitem_lock);
	tasklet_schedule(&tipc_tasklet);
	return 0;
}

static void process_signal_queue(unsigned long dummy)
{
	struct queue_item *__volatile__ item;
	struct list_head *l, *n;

	spin_lock_bh(&qitem_lock);
	list_for_each_safe(l, n, &signal_queue_head) {
		item = list_entry(l, struct queue_item, next_signal);
		list_del(&item->next_signal);
		spin_unlock_bh(&qitem_lock);
		item->handler(item->data);
		spin_lock_bh(&qitem_lock);
		kmem_cache_free(tipc_queue_item_cache, item);
	}
	spin_unlock_bh(&qitem_lock);
}

int handler_start(void)
{
	tipc_queue_item_cache = 
		kmem_cache_create("tipc_queue_items", sizeof(struct queue_item),
				  0, SLAB_HWCACHE_ALIGN, NULL, NULL);
	if (!tipc_queue_item_cache)
		return -ENOMEM;

	INIT_LIST_HEAD(&signal_queue_head);
	tasklet_enable(&tipc_tasklet);
	handler_enabled = 1;
	return 0;
}

void handler_stop(void)
{
	struct list_head *l, *n;
	struct queue_item *item; 

	if (!handler_enabled)
		return;

	handler_enabled = 0;
	tasklet_disable(&tipc_tasklet);
	tasklet_kill(&tipc_tasklet);

	spin_lock_bh(&qitem_lock);
	list_for_each_safe(l, n, &signal_queue_head) {
		item = list_entry(l, struct queue_item, next_signal);
		list_del(&item->next_signal);
		kmem_cache_free(tipc_queue_item_cache, item);
	}
	spin_unlock_bh(&qitem_lock);

	kmem_cache_destroy(tipc_queue_item_cache);
}

