/* ------------------------------------------------------------------------
 *
 * dbg.h
 *
 * Short description: Include file for TIPC print buffer routines
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2003-2005, Ericsson Research Canada
 * Copyright (c) 2005, Wind River Systems
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the names of the copyright holders nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *  Created 1997-02-29 by Jon Maloy
 *
 * ------------------------------------------------------------------------
 *
 *  $Id: dbg.h,v 1.13 2005/11/07 15:16:45 ajstephens Exp $
 *
 *  Revision history:
 *  ----------------
 *  $Log: dbg.h,v $
 *  Revision 1.13  2005/11/07 15:16:45  ajstephens
 *  Revised link debugging code to enable per-link info capture
 *
 *  Revision 1.12  2005/08/25 15:51:40  ajstephens
 *  Major overhaul of configuration code; other bug fixes
 *
 *  Revision 1.11  2005/08/05 20:35:48  ajstephens
 *  More major overhaul to socket code, plus other modifications
 *
 *  Revision 1.10  2005/06/16 12:49:30  ajstephens
 *  More cleanup; socket API revisions; added netlink configuration support
 *
 *  Revision 1.9  2005/06/01 19:13:26  ajstephens
 *  Reorganize & rename some files; more cleanup
 *
 *  Revision 1.8  2005/05/25 12:39:22  ajstephens
 *  Major cleanup (null pointer checks, print buffer rework, startup failure, cosmetic, ...)
 *
 *  Revision 1.7  2005/05/02 21:19:23  jonmaloy
 *  File structure changes as preparation for Linux kernel inclusion
 *
 *  Revision 1.6  2005/02/24 18:36:22  ajstephens
 *  Print buffers now wrap around properly, plus other enhancements.
 *
 *  Revision 1.1  2004/09/23 20:01:30  jonmaloy
 *  *** empty log message ***
 *
 *  Revision 1.5  2004/06/09 23:14:46  jonmaloy
 *  Added dynamic module configuration support
 *
 *  Revision 1.11  2003/06/11 01:15:48  telorb
 *  Checked in with epsi by lmcjoma
 *
 *  Revision 1.0 2003/02/02 03:51:00   lmcabda
 *  Released as an Open Source product under a BSD License
 *
 *  Rev	Date		Rev by	Reason
 *  ---	----		------	------
 *
 *  PA1	1997-02-29	Jon Maloy	Created.
 *  PA2	2000-10-20	Jon Maloy	Converted from C++ to C.
 *
 * ------------------------------------------------------------------------
*/

#ifndef _TIPC_DBG_H
#define _TIPC_DBG_H

struct print_buf {
	char *buf;
	u32 size;
	char *crs;
	struct print_buf *next;
};

void printbuf_init(struct print_buf *pb, char *buf, u32 sz);
void printbuf_reset(struct print_buf *pb);
int  printbuf_empty(struct print_buf *pb);
int  printbuf_validate(struct print_buf *pb);
void printbuf_move(struct print_buf *pb_to, struct print_buf *pb_from);

void log_reinit(int log_size);
void log_stop(void);

struct sk_buff *log_resize(const void *req_tlv_area, int req_tlv_space);
struct sk_buff *log_dump(void);

#endif
