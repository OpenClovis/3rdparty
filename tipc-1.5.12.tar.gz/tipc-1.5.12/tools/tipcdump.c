/* ------------------------------------------------------------------------
 *
 * tipcdump.c
 *
 * Short description:
 * 
 * ------------------------------------------------------------------------
 *
 * Copyright (c) 2004,2005 Nortel Networks Inc
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this 
 * list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 * Neither the name of Ericsson Research Canada nor the names of its 
 * contributors may be used to endorse or promote products derived from this 
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * ------------------------------------------------------------------------
 *
 *   Created 2005      Ed Housey
 *
 * ------------------------------------------------------------------------
 */



#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <sys/param.h>
#include <sys/poll.h>
#include <sys/ioctl.h>
#include <netdb.h>
#include <errno.h>
#include <fcntl.h>
#include <tipc.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <ctype.h>
#include <signal.h>

#include <tipcdump.h>

#define ORIGINATING_NODE			1
#define DESTINATION_NODE			2
#define TIPCDUMP_CHAR_FILE			"/dev/tipcdump"
#define PROC_DEVICES				"/proc/devices"


/*
** Represents the "size" field when tipcdump is writing stats to a file.
** The flag indicates to tipcdump to read the next data in as a stats structure.
*/
#define TIPCDUMP_STATS_LOGGED		0xffffffff

typedef struct tipcdump_stats
{
	uint64_t	dropped_messages;
	struct timeval	start_time;
	struct timeval	curr_time;

	/*
	** Stats recorded after filtering.
	*/
	uint64_t	f_msg_recv;
	uint64_t	f_msg_sent;
	uint64_t	f_bytes_recv;
	uint64_t	f_bytes_sent;
	uint64_t	f_local_msg_recv;
	uint64_t	f_local_msg_sent;
	uint64_t	f_local_bytes_recv;
	uint64_t	f_local_bytes_sent;

	/*
	** Total stats recorded before filtering.
	*/
	uint64_t	t_msg_recv;
	uint64_t	t_msg_sent;
	uint64_t	t_bytes_recv;
	uint64_t	t_bytes_sent;
	uint64_t	t_local_msg_recv;
	uint64_t	t_local_msg_sent;
	uint64_t	t_local_bytes_recv;
	uint64_t	t_local_bytes_sent;
} tipcdump_stats_t;


typedef struct tipcdump_buf
{
	char				buf[TIPCDUMP_MAX_PAYLOAD_SIZE];
	ssize_t				size;
	char				msg_direction;
	char				msg_type;
	uint32_t			orig_node;
	uint32_t			dest_node;
	uint32_t			type;
	uint32_t			instance;
	time_t				msg_sec;
	suseconds_t			msg_usec;
} tipcdump_buf_t;


typedef struct tipcdump_info
{
	char				*prog;			/* program invocation name */
	uint32_t			mynode;
	char				dumpstats;		/* SIGUSR1 received will dump current stats */
	char				exit;			/* SIGINT received will dump current stats and exit */
	tipcdump_stats_t	stats;
	char				devfile[32];	/* /dev/tipcdump file */
	int					devfd;			/* /dev/tipcdump file descriptor */
	char				wflag;			/* -w <wfilename> */
	char				*wfilename;
	int					wfd;
	char				rflag;			/* -r <rfilename> */
	char				*rfilename;
	int					rfd;
	char				Aflag;			/* -A do not display ascii format */
	char				Xflag;			/* -X do not display hex format */
	char				Sflag;			/* -S do not capture Send messages */
	char				Rflag;			/* -R do not capture Receive messages */
	char				Iflag;			/* -I do not capture Internal messages */
	char				Pflag;			/* -I do not capture Internal messages */
	char				cflag;			/* -c <count> continue until <count> messages received */
	unsigned int		count;
	char				oflag;			/* -o <onodelist> specify originating node list */
	char				*onodelist;		/* <onodelist> format is <z.c.n> or <z1.c1.n1>,<z2.c2.n2> */
	int					oz1, oc1, on1;
	int					oz2, oc2, on2;
	char				dflag;			/* -d <dnodelist> specify destination node list */
	char				*dnodelist;		/* <dnodelist> format is <z.c.n> or <z1.c1.n1>,<z2.c2.n2> */
	int					dz1, dc1, dn1;
	int					dz2, dc2, dn2;
	int					tflag;			/* -t <bitmask>,<result> ...valid if (type & bitmask) = result */
	char				*tlist;
	uint32_t			t_bitmask;
	uint32_t			t_result;
	int					iflag;			/* -i <instance> */
	char				*ilist;			/* <ilist> format is <instance> or <inst_lower>,<inst_upper> */
	uint32_t			i_lower;
	uint32_t			i_upper;
} tipcdump_info_t;


tipcdump_buf_t		tipcdump_buf;
tipcdump_info_t		tipcdump_info;


char	ascii_table[128][6] = 
{ {"(nul)"}, {"(soh)"}, {"(stx)"}, {"(etx)"}, {"(eot)"}, {"(enq)"}, {"(ack)"}, {"(bel)"}, {" (bs)"},
  {" (ht)"}, {" (nl)"}, {" (vt)"}, {" (np)"}, {" (cr)"}, {" (so)"}, {" (si)"}, {"(dle)"}, {"(dc1)"},
  {"(dc2)"}, {"(dc3)"}, {"(dc4)"}, {"(nak)"}, {"(syn)"}, {"(etb)"}, {"(can)"}, {" (em)"}, {"(sub)"},
  {"(esc)"}, {" (fs)"}, {" (gs)"}, {" (rs)"}, {" (us)"}, {" (sp)"}, {"    !"}, {"    \""}, {"    #"},
  {"    $"}, {"    %"}, {"    &"}, {"    '"}, {"    ("}, {"    )"}, {"    *"}, {"    +"}, {"    ,"},
  {"    -"}, {"    ."}, {"    /"}, {"    0"}, {"    1"}, {"    2"}, {"    3"}, {"    4"}, {"    5"},
  {"    6"}, {"    7"}, {"    8"}, {"    9"}, {"    :"}, {"    ;"}, {"    <"}, {"    ="}, {"    >"},
  {"    ?"}, {"    @"}, {"    A"}, {"    B"}, {"    C"}, {"    D"}, {"    E"}, {"    F"}, {"    G"},
  {"    H"}, {"    I"}, {"    J"}, {"    K"}, {"    L"}, {"    M"}, {"    N"}, {"    O"}, {"    P"},
  {"    Q"}, {"    R"}, {"    S"}, {"    T"}, {"    U"}, {"    V"}, {"    W"}, {"    X"}, {"    Y"},
  {"    Z"}, {"    ["}, {"    \\"}, {"    ]"}, {"    ^"}, {"    _"}, {"    `"}, {"    a"}, {"    b"},
  {"    c"}, {"    d"}, {"    e"}, {"    f"}, {"    g"}, {"    h"}, {"    i"}, {"    j"}, {"    k"},
  {"    l"}, {"    m"}, {"    n"}, {"    o"}, {"    p"}, {"    q"}, {"    r"}, {"    s"}, {"    t"},
  {"    u"}, {"    v"}, {"    w"}, {"    x"}, {"    y"}, {"    z"}, {"    {"}, {"    |"}, {"    }"},
  {"    ~"}, {"(del)"} };


int
tipcdump_exit(int exitval)
{
	if (tipcdump_info.devfd != -1)
	{
		close(tipcdump_info.devfd);
	}

	if (tipcdump_info.rfd != -1)
	{
		close(tipcdump_info.rfd);
	}

	if (tipcdump_info.wfd != -1)
	{
		close(tipcdump_info.wfd);
	}

	exit(exitval);
}


void
tipcdump_sigint(int arg1)
{
	tipcdump_info.exit = TRUE;
}


void
tipcdump_sigusr1(int arg1)
{
	tipcdump_info.dumpstats = TRUE;
}


void
tipcdump_print_usage()
{
	fprintf(stderr, "\n\n");
	fprintf(stderr, "Usage: %s\n", tipcdump_info.prog);
	fprintf(stderr, "    [ -h ]                         Display this message\n");
	fprintf(stderr, "    [ -w <file> ]                  Log unformatted messages to <file>\n");
	fprintf(stderr, "    [ -r <file> ]                  Read unformatted messages from <file> and process\n");
	fprintf(stderr, "    [ -A ]                         Do NOT display ASCII format when dumping messages\n");
	fprintf(stderr, "    [ -X ]                         Do NOT display HEX format when dumping messages\n");
	fprintf(stderr, "    [ -S ]                         Do NOT capture messages sent by this node\n");
	fprintf(stderr, "    [ -R ]                         Do NOT capture messages received by this node\n");
	fprintf(stderr, "    [ -I ]                         Do NOT capture internal messages\n");
	fprintf(stderr, "    [ -P ]                         Do NOT capture payload messages\n");
	fprintf(stderr, "    [ -c <cnt> ]                   Stop after receiving a total of <cnt> messages\n");
	fprintf(stderr, "    [ -o <z.c.n> ]                 Specify originating node zone.cluster.node\n");
	fprintf(stderr, "    [ -o <z1.c1.n1>,<z2.c2.n2> ]   Specify originating node range where z1.c1.n1 < z2.c2.n2\n");
	fprintf(stderr, "    [ -d <z.c.n> ]                 Specify destination node zone.cluster.node\n");
	fprintf(stderr, "    [ -d <z1.c1.n1>,<z2.c2.n2> ]   Specify destination node range where z1.c1.n1 < z2.c2.n2\n");
	fprintf(stderr, "    [ -t <result> ]                Specify type (hex)\n");
	fprintf(stderr, "    [ -t <bitmask>,<result> ]      Specify type bitmask to AND against type, and result (hex)\n");
	fprintf(stderr, "    [ -i <instance> ]              Specify instance (hex)\n");
	fprintf(stderr, "    [ -i <inst_low>,<inst_high> ]  Specify instance range where inst_low < inst_high (hex)\n");
	fprintf(stderr, "    SIGUSR1 signal                 Dump statistics\n");
	fprintf(stderr, "    SIGINT  signal                 Terminate program\n");
	fprintf(stderr, "\n\n");
}


int
tipcdump_initialize(int argc, char *argv[])
{
	FILE	*fp;
	char	*c, devname[32];
	int		majornum, tmp_majornum, retval;
	dev_t	device;


	/*
	** Register a ctrl-c to exit program.
	*/
	signal(SIGINT, tipcdump_sigint);

	/*
	** Register a USR1 signal to dump stats.
	*/
	signal(SIGUSR1, tipcdump_sigusr1);

	/*
	** Init tipcdump_info fields.
	*/
	tipcdump_info.prog = argv[0];
	tipcdump_info.dumpstats = FALSE;
	tipcdump_info.exit = FALSE;
	memset(&(tipcdump_info.stats), '\0', sizeof(tipcdump_stats_t));

	/*
	** Update the current time in the stats structure.
	*/
	retval = gettimeofday(&(tipcdump_info.stats.start_time), NULL);
	if (retval == -1)
	{
		fprintf(stderr, "%s: ERROR: gettimeofday failed, errno=%d\n",
			tipcdump_info.prog,
			errno);
		tipcdump_exit(-1);
	}

	strcpy(tipcdump_info.devfile, TIPCDUMP_CHAR_FILE);
	tipcdump_info.devfd = -1;
	tipcdump_info.wflag = 0;
	tipcdump_info.wfilename = NULL;
	tipcdump_info.wfd = -1;
	tipcdump_info.rflag = 0;
	tipcdump_info.rfilename = NULL;
	tipcdump_info.rfd = -1;
	tipcdump_info.Aflag = 0;
	tipcdump_info.Xflag = 0;
	tipcdump_info.Sflag = 0;
	tipcdump_info.Rflag = 0;
	tipcdump_info.Iflag = 0;
	tipcdump_info.Pflag = 0;
	tipcdump_info.cflag = 0;
	tipcdump_info.count = 0;
	tipcdump_info.oflag = 0;
	tipcdump_info.onodelist = NULL;
	tipcdump_info.oz1 = 0;
	tipcdump_info.oc1 = 0;
	tipcdump_info.on1 = 0;
	tipcdump_info.oz2 = 0;
	tipcdump_info.oc2 = 0;
	tipcdump_info.on2 = 0;
	tipcdump_info.dflag = 0;
	tipcdump_info.dnodelist = NULL;
	tipcdump_info.dz1 = 0;
	tipcdump_info.dc1 = 0;
	tipcdump_info.dn1 = 0;
	tipcdump_info.dz2 = 0;
	tipcdump_info.dc2 = 0;
	tipcdump_info.dn2 = 0;
	tipcdump_info.tflag = 0;
	tipcdump_info.tlist = NULL;
	tipcdump_info.t_bitmask = 0xffffffff;
	tipcdump_info.t_result = 0;
	tipcdump_info.iflag = 0;
	tipcdump_info.ilist = NULL;
	tipcdump_info.i_lower = 0;
	tipcdump_info.i_upper = 0;


	/*
	** Create the TIPCDUMP_CHAR_FILE. First find the major num from
	** PROC_DEVICES (/proc/devices) file.
	*/
	fp = fopen(PROC_DEVICES, "r");
	if (fp == NULL)
	{
		fprintf(stderr, "%s: ERROR: open device file %s, errno=%d\n",
			tipcdump_info.prog,
			PROC_DEVICES,
			errno);
		tipcdump_exit(-1);
	}

	majornum = -1;
	while (1)
	{
		c = fgets(tipcdump_buf.buf, 256, fp);
		tipcdump_buf.buf[strlen(tipcdump_buf.buf) - 1] = '\0';
		if (c == ((char *) EOF) || c == ((char *) '\0'))
		{
			break;
		}

		sscanf(c, "%d %s", &tmp_majornum, devname);
		if (strcmp(devname, TIPCDUMP_ID) == 0)
		{
			majornum = tmp_majornum;
			break;
		}
	}
	fclose(fp);

	if (majornum == -1)
	{
		fprintf(stderr, "%s: ERROR: Unable to locate %s majornum in %s\n",
			tipcdump_info.prog,
			TIPCDUMP_CHAR_FILE,
			PROC_DEVICES);
		tipcdump_exit(-1);
	}
	else
	{
		/*
		** Delete character file and issue mknod to recreate TIPCDUMP_CHAR_FILE.
		*/
		unlink(TIPCDUMP_CHAR_FILE);
		device = makedev(majornum, 0);
		mknod(TIPCDUMP_CHAR_FILE,
			(S_IFCHR | S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH),
			device);
	}

	/*
	** Init tipcdump_buf fields.
	*/
	bzero(tipcdump_buf.buf, TIPCDUMP_MAX_PAYLOAD_SIZE);
	tipcdump_buf.size = 0;

	return(0);
}


int
tipcdump_verify_instance()
{
	char	*c, inst_list[22];


	if (strlen(tipcdump_info.ilist) > 21)
	{
		return(-1);
	}

	bzero(inst_list, 22);
	strncpy(inst_list, tipcdump_info.ilist, 21);
	inst_list[22] = '\0';
	c = (char *) strtok(inst_list, ",");
	if (c != NULL)
	{
		tipcdump_info.i_lower = strtoul(c, NULL, 16);
	}
	else
	{
		return(-1);
	}

	c = (char *) strtok(NULL, ",");
	if (c == NULL)
	{
		/*
		** Only 1 instance specified.
		*/
		tipcdump_info.i_upper = tipcdump_info.i_lower;
		return(0);
	}
	else
	{
		tipcdump_info.i_upper = strtoul(c, NULL, 16);
	}

	/*
	** i_lower must be <= to the i_upper.
	*/
	if (tipcdump_info.i_lower > tipcdump_info.i_upper)
	{
		return(-1);
	}
	return(0);
}


int
tipcdump_verify_type()
{
	char	*c, type_list[22];


	if (strlen(tipcdump_info.tlist) > 21)
	{
		return(-1);
	}

	bzero(type_list, 22);
	strncpy(type_list, tipcdump_info.tlist, 21);
	type_list[22] = '\0';
	c = (char *) strtok(type_list, ",");
	if (c != NULL)
	{
		tipcdump_info.t_result = strtoul(c, NULL, 16);
	}
	else
	{
		return(-1);
	}

	c = (char *) strtok(NULL, ",");
	if (c == NULL)
	{
		/*
		** Only type result specified. The t_bitmask is
		** already initialized to 0xffffffff.
		*/
		return(0);
	}
	else
	{
		/*
		** 2 values, so the first value is the bitmask,
		** and the second value is the result. We already
		** saved the first value (the bitmask) in t_result,
		** so move this value into the bitmask and get the
		** t_result from the second value.
		*/
		tipcdump_info.t_bitmask = tipcdump_info.t_result;
		tipcdump_info.t_result = strtoul(c, NULL, 16);
	}
	return(0);
}


int
tipcdump_convert_tuple_to_zcn(int nodetype)
{
	char	*c, tuple[28];


	if (nodetype == ORIGINATING_NODE)
	{
		if (strlen(tipcdump_info.onodelist) > 27)
		{
			return(-1);
		}

		bzero(tuple, 28);
		strncpy(tuple, tipcdump_info.onodelist, 27);
		tuple[27] = '\0';
		c = (char *) strtok(tuple, ".");
		if (c != NULL)
		{
			tipcdump_info.oz1 = atoi(c);
		}
		else
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".");
		if (c != NULL)
		{
			tipcdump_info.oc1 = atoi(c);
		}
		else
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".,");
		if (c != NULL)
		{
			tipcdump_info.on1 = atoi(c);
		}
		else
		{
			return(-1);
		}

		/*
		** Range test the Z.C.N tuples.
		*/
		if (tipcdump_info.oz1 < ZONE_MIN || tipcdump_info.oz1 > ZONE_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.oc1 < CLUSTER_MIN || tipcdump_info.oc1 > CLUSTER_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.on1 < NODE_MIN || tipcdump_info.on1 > NODE_MAX)
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".");
		if (c == NULL)
		{
			/*
			** Only 1 tuple specified.
			*/
			tipcdump_info.oz2 = tipcdump_info.oz1;
			tipcdump_info.oc2 = tipcdump_info.oc1;
			tipcdump_info.on2 = tipcdump_info.on1;
			return(0);
		}
		else
		{
			tipcdump_info.oz2 = atoi(c);
		}

		c = (char *) strtok(NULL, ".");
		if (c != NULL)
		{
			tipcdump_info.oc2 = atoi(c);
		}
		else
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".");
		if (c != NULL)
		{
			tipcdump_info.on2 = atoi(c);
		}
		else
		{
			return(-1);
		}

		/*
		** Range test the Z.C.N tuples.
		*/
		if (tipcdump_info.oz2 < ZONE_MIN || tipcdump_info.oz2 > ZONE_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.oc2 < CLUSTER_MIN || tipcdump_info.oc2 > CLUSTER_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.on2 < NODE_MIN || tipcdump_info.on2 > NODE_MAX)
		{
			return(-1);
		}

		/*
		** First tuple must be <= to the second tuple.
		*/
		if (tipcdump_info.oz1 > tipcdump_info.oz2)
		{
			return(-1);
		}
		if (tipcdump_info.oc1 > tipcdump_info.oc2)
		{
			return(-1);
		}
		if (tipcdump_info.on1 > tipcdump_info.on2)
		{
			return(-1);
		}
		return(0);
	}
	else	/* nodetype == DESTINATION_NODE */
	{
		if (strlen(tipcdump_info.dnodelist) > 27)
		{
			return(-1);
		}

		bzero(tuple, 28);
		strncpy(tuple, tipcdump_info.dnodelist, 27);
		tuple[27] = '\0';
		c = (char *) strtok(tuple, ".");
		if (c != NULL)
		{
			tipcdump_info.dz1 = atoi(c);
		}
		else
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".");
		if (c != NULL)
		{
			tipcdump_info.dc1 = atoi(c);
		}
		else
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".,");
		if (c != NULL)
		{
			tipcdump_info.dn1 = atoi(c);
		}
		else
		{
			return(-1);
		}

		/*
		** Range test the Z.C.N tuples.
		*/
		if (tipcdump_info.dz1 < ZONE_MIN || tipcdump_info.dz1 > ZONE_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.dc1 < CLUSTER_MIN || tipcdump_info.dc1 > CLUSTER_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.dn1 < NODE_MIN || tipcdump_info.dn1 > NODE_MAX)
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".");
		if (c == NULL)
		{
			/*
			** Only 1 tuple specified.
			*/
			tipcdump_info.dz2 = tipcdump_info.dz1;
			tipcdump_info.dc2 = tipcdump_info.dc1;
			tipcdump_info.dn2 = tipcdump_info.dn1;
			return(0);
		}
		else
		{
			tipcdump_info.dz2 = atoi(c);
		}

		c = (char *) strtok(NULL, ".");
		if (c != NULL)
		{
			tipcdump_info.dc2 = atoi(c);
		}
		else
		{
			return(-1);
		}

		c = (char *) strtok(NULL, ".");
		if (c != NULL)
		{
			tipcdump_info.dn2 = atoi(c);
		}
		else
		{
			return(-1);
		}

		/*
		** Range test the Z.C.N tuples.
		*/
		if (tipcdump_info.dz2 < ZONE_MIN || tipcdump_info.dz2 > ZONE_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.dc2 < CLUSTER_MIN || tipcdump_info.dc2 > CLUSTER_MAX)
		{
			return(-1);
		}
		if (tipcdump_info.dn2 < NODE_MIN || tipcdump_info.dn2 > NODE_MAX)
		{
			return(-1);
		}

		/*
		** First tuple must be <= to the second tuple.
		*/
		if (tipcdump_info.dz1 > tipcdump_info.dz2)
		{
			return(-1);
		}
		if (tipcdump_info.dc1 > tipcdump_info.dc2)
		{
			return(-1);
		}
		if (tipcdump_info.dn1 > tipcdump_info.dn2)
		{
			return(-1);
		}
		return(0);
	}
}


int
tipcdump_parse_args(int argc, char *argv[])
{
	int		c, retval;


	opterr = 0;
	while ((c = getopt(argc, argv, "hw:r:AXSRIPc:o:d:t:i:")) != -1)
	{
		switch (c)
		{
			case 'h':
				tipcdump_print_usage();
				tipcdump_exit(0);
			break;

			case 'w':
				if (tipcdump_info.wflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.wflag)++;
				tipcdump_info.wfilename = optarg;
			break;

			case 'r':
				if (tipcdump_info.rflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.rflag)++;
				tipcdump_info.rfilename = optarg;
			break;

			case 'A':
				if (tipcdump_info.Aflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.Aflag++);
			break;

			case 'X':
				if (tipcdump_info.Xflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.Xflag++);
			break;

			case 'S':
				if (tipcdump_info.Sflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.Sflag++);
			break;

			case 'R':
				if (tipcdump_info.Rflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.Rflag++);
			break;

			case 'I':
				if (tipcdump_info.Iflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.Iflag++);
			break;

			case 'P':
				if (tipcdump_info.Pflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.Pflag++);
			break;

			case 'c':
				if (tipcdump_info.cflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.cflag++);
				tipcdump_info.count = atoi(optarg);
			break;


			case 'o':
				if (tipcdump_info.oflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.oflag++);
				tipcdump_info.onodelist = optarg;
			break;

			case 'd':
				if (tipcdump_info.dflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.dflag++);
				tipcdump_info.dnodelist = optarg;
			break;

			case 't':
				if (tipcdump_info.tflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.tflag++);
				tipcdump_info.tlist = optarg;
			break;

			case 'i':
				if (tipcdump_info.iflag)
				{
					fprintf(stderr, "\nOption %c may be specified at most once\n", c);
					tipcdump_print_usage();
					tipcdump_exit(-1);
				}
				(tipcdump_info.iflag++);
				tipcdump_info.ilist = optarg;
			break;

			default:
				fprintf(stderr, "\nUnrecognized option: %c\n", c);
				tipcdump_print_usage();
				tipcdump_exit(-1);
			break;
		}
	}

	/*
	** If -c <cnt> is specified, confirm <cnt> is != 0.
	*/
	if (tipcdump_info.cflag)
	{
		if (tipcdump_info.count == 0)
		{
			fprintf(stderr, "\nMust specifiy non-zero value with -c option\n");
			tipcdump_print_usage();
			tipcdump_exit(-1);
		}
	}
			
	/*
	** If -r <file> is specified, none of the filter options are permitted.
	** This is done because it will confuse the user if any statistics were
	** recorded in the datafile.
	*/
	if (tipcdump_info.rflag)
	{
		if (tipcdump_info.Sflag ||
			tipcdump_info.Rflag ||
			tipcdump_info.Iflag ||
			tipcdump_info.Pflag ||
			tipcdump_info.cflag ||
			tipcdump_info.oflag ||
			tipcdump_info.dflag ||
			tipcdump_info.iflag ||
			tipcdump_info.tflag)
		{
			fprintf(stderr, "\nFilter options not allowed with -r option\n");
			tipcdump_print_usage();
			tipcdump_exit(-1);
		}
	}

	/*
	** Verify originating and destination nodelists, if specified.
	*/
	if (tipcdump_info.oflag)
	{
		retval = tipcdump_convert_tuple_to_zcn(ORIGINATING_NODE);
		if (retval == -1)
		{
			fprintf(stderr, "Unrecognized or invalid originating node list\n");
			tipcdump_print_usage();
			tipcdump_exit(-1);
		}
	}
	if (tipcdump_info.dflag)
	{
		retval = tipcdump_convert_tuple_to_zcn(DESTINATION_NODE);
		if (retval == -1)
		{
			fprintf(stderr, "Unrecognized or invalid destination node list\n");
			tipcdump_print_usage();
			tipcdump_exit(-1);
		}
	}

	/*
	** Verify the instance argument, if specified.
	*/
	if (tipcdump_info.iflag)
	{
		retval = tipcdump_verify_instance();
		if (retval == -1)
		{
			fprintf(stderr, "Unrecognized or invalid instance field\n");
			tipcdump_print_usage();
			tipcdump_exit(-1);
		}
	}

	/*
	** Verify the type argument, if specified.
	*/
	if (tipcdump_info.tflag)
	{
		retval = tipcdump_verify_type();
		if (retval == -1)
		{
			fprintf(stderr, "Unrecognized or invalid instance field\n");
			tipcdump_print_usage();
			tipcdump_exit(-1);
		}
	}
	

#if 0
printf("tipcdump_info.wflag=%d, wfilename=%s\n", tipcdump_info.wflag, tipcdump_info.wfilename);
printf("tipcdump_info.rflag=%d, rfilename=%s\n", tipcdump_info.rflag, tipcdump_info.rfilename);
printf("tipcdump_info.Aflag=%d\n", tipcdump_info.Aflag);
printf("tipcdump_info.Xflag=%d\n", tipcdump_info.Xflag);
printf("tipcdump_info.Sflag=%d\n", tipcdump_info.Sflag);
printf("tipcdump_info.Rflag=%d\n", tipcdump_info.Rflag);
printf("tipcdump_info.Iflag=%d\n", tipcdump_info.Iflag);
printf("tipcdump_info.Pflag=%d\n", tipcdump_info.Pflag);
printf("tipcdump_info.cflag=%d, count=%d\n", tipcdump_info.cflag, tipcdump_info.count);
printf("tipcdump_info.oflag=%d, onodelist=%s\n", tipcdump_info.oflag, tipcdump_info.onodelist);
printf("tipcdump_info.dflag=%d, dnodelist=%s\n", tipcdump_info.dflag, tipcdump_info.dnodelist);
printf("onodelist=%d.%d.%d    %d.%d.%d\n",
tipcdump_info.oz1,
tipcdump_info.oc1,
tipcdump_info.on1,
tipcdump_info.oz2,
tipcdump_info.oc2,
tipcdump_info.on2);
printf("dnodelist=%d.%d.%d    %d.%d.%d\n",
tipcdump_info.dz1,
tipcdump_info.dc1,
tipcdump_info.dn1,
tipcdump_info.dz2,
tipcdump_info.dc2,
tipcdump_info.dn2);
printf("tipcdump_info.iflag=%d, instance=%s\n", tipcdump_info.iflag, tipcdump_info.ilist);
printf("i_lower=%d, i_upper=%d\n", tipcdump_info.i_lower, tipcdump_info.i_upper);
printf("tipcdump_info.tflag=%d, type=%s\n", tipcdump_info.tflag, tipcdump_info.tlist);
printf("t_bitmask=0x%x, t_result=0x%x\n", tipcdump_info.t_bitmask, tipcdump_info.t_result);
#endif

	return(0);
}


void
tipcdump_stats_stdout()
{
	unsigned int	elapsed_time;


	printf("\n\n\nRetrieved statistics:\n");
	printf("  Start time=%s", ctime(&tipcdump_info.stats.start_time.tv_sec));
	printf("        Timestamp=%d.%d\n",
		(int) tipcdump_info.stats.start_time.tv_sec,
		(int) tipcdump_info.stats.start_time.tv_usec);
	printf("  Current time=%s", ctime(&tipcdump_info.stats.curr_time.tv_sec));
	printf("        Timestamp=%d.%d\n",
		(int) tipcdump_info.stats.curr_time.tv_sec,
		(int) tipcdump_info.stats.curr_time.tv_usec);

	elapsed_time = (int) (tipcdump_info.stats.curr_time.tv_sec - tipcdump_info.stats.start_time.tv_sec);
	printf("  Elapsed_time=%d sec\n", elapsed_time);

	printf("  Total messages dropped: %llu\n",
		tipcdump_info.stats.dropped_messages);

	printf("  Total messages sent: %llu (%llu bytes)\n",
		tipcdump_info.stats.t_msg_sent,
		tipcdump_info.stats.t_bytes_sent);
	printf("  Total messages sent/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.t_msg_sent / (uint64_t) elapsed_time),
		(tipcdump_info.stats.t_bytes_sent / (uint64_t) elapsed_time));

	printf("  Total messages recv: %llu (%llu bytes)\n",
		tipcdump_info.stats.t_msg_recv,
		tipcdump_info.stats.t_bytes_recv);
	printf("  Total messages recv/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.t_msg_recv / (uint64_t) elapsed_time),
		(tipcdump_info.stats.t_bytes_recv / (uint64_t) elapsed_time));

	printf("  Total local messages sent: %llu (%llu bytes)\n",
		tipcdump_info.stats.t_local_msg_sent,
		tipcdump_info.stats.t_local_bytes_sent);
	printf("  Total local messages sent/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.t_local_msg_sent / (uint64_t) elapsed_time),
		(tipcdump_info.stats.t_local_bytes_sent / (uint64_t) elapsed_time));

	printf("  Total local messages recv: %llu (%llu bytes)\n",
		tipcdump_info.stats.t_local_msg_recv,
		tipcdump_info.stats.t_local_bytes_recv);
	printf("  Total local messages recv/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.t_local_msg_recv / (uint64_t) elapsed_time),
		(tipcdump_info.stats.t_local_bytes_recv / (uint64_t) elapsed_time));


	printf("  Total filtered messages sent: %llu (%llu bytes)\n",
		tipcdump_info.stats.f_msg_sent,
		tipcdump_info.stats.f_bytes_sent);
	printf("  Total filtered messages sent/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.f_msg_sent / (uint64_t) elapsed_time),
		(tipcdump_info.stats.f_bytes_sent / (uint64_t) elapsed_time));

	printf("  Total filtered messages recv: %llu (%llu bytes)\n",
		tipcdump_info.stats.f_msg_recv,
		tipcdump_info.stats.f_bytes_recv);
	printf("  Total filtered messages recv/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.f_msg_recv / (uint64_t) elapsed_time),
		(tipcdump_info.stats.f_bytes_recv / (uint64_t) elapsed_time));

	printf("  Total filtered local messages sent: %llu (%llu bytes)\n",
		tipcdump_info.stats.f_local_msg_sent,
		tipcdump_info.stats.f_local_bytes_sent);
	printf("  Total filtered local messages sent/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.f_local_msg_sent / (uint64_t) elapsed_time),
		(tipcdump_info.stats.f_local_bytes_sent / (uint64_t) elapsed_time));

	printf("  Total filtered local messages recv: %llu (%llu bytes)\n",
		tipcdump_info.stats.f_local_msg_recv,
		tipcdump_info.stats.f_local_bytes_recv);
	printf("  Total filtered local messages recv/sec: %llu msgs/sec (%llu bytes/sec)\n",
		(tipcdump_info.stats.f_local_msg_recv / (uint64_t) elapsed_time),
		(tipcdump_info.stats.f_local_bytes_recv / (uint64_t) elapsed_time));
}


void
tipcdump_message_stdout()
{
	int		i, j;
	char		output_hex_buf[50], output_ascii_buf[50];
	char		tmp_buf[10];


	printf("\n\n\nRetrieved message: time=%s", ctime(&(tipcdump_buf.msg_sec)));
	printf("  Timestamp=%d.%d, Size=%d bytes, Direction=%s, MsgType=%s (val=%d)\n",
		(int) tipcdump_buf.msg_sec,
		(int) tipcdump_buf.msg_usec,
		tipcdump_buf.size,
		((tipcdump_buf.msg_direction == TIPCDUMP_MSG_SENT) ? "SEND" : "RECEIVED"),
		((tipcdump_buf.msg_type <= 3) ? "PAYLOAD" : "INTERNAL"), tipcdump_buf.msg_type);

	printf("  Originating node=<%d.%d.%d>, Destination node=<%d.%d.%d>\n",
		ZONE(tipcdump_buf.orig_node), CLUSTER(tipcdump_buf.orig_node), NODE(tipcdump_buf.orig_node),
		ZONE(tipcdump_buf.dest_node), CLUSTER(tipcdump_buf.dest_node), NODE(tipcdump_buf.dest_node));

	if (tipcdump_buf.msg_type == 2)
	{
		printf("  Type=0x%x, Instance=0x%x\n\n", tipcdump_buf.type, tipcdump_buf.instance);
	}

	if (tipcdump_info.Aflag && tipcdump_info.Xflag)
	{
		/*
		** Don't print out anything.
		*/
	}
	else
	{
		for (i = 0; i < tipcdump_buf.size; i+=4)
		{
			printf("buf[%03d]: ", i);
			bzero(output_hex_buf, 50);
			bzero(output_ascii_buf, 50);
			for (j = 0; j < 4; j++)
			{
				if ((i + j) < tipcdump_buf.size)
				{
					bzero(tmp_buf, 10);
					if (tipcdump_info.Xflag == 0)
					{
						sprintf(tmp_buf, "0x%02x ", tipcdump_buf.buf[i + j] & 0x000000ff);
					}
					else
					{
						sprintf(tmp_buf, " ");
					}
					strcat(output_hex_buf, tmp_buf);

					bzero(tmp_buf, 10);
					if (tipcdump_info.Aflag == 0)
					{
						sprintf(tmp_buf, "%s ", ascii_table[tipcdump_buf.buf[i + j] & 0x0000007f]);
					}
					else
					{
						sprintf(tmp_buf, " ");
					}
					strcat(output_ascii_buf, tmp_buf);
				}
				else
				{
					strcat(output_hex_buf, "     ");
					strcat(output_ascii_buf, "      ");
				}
			}
			printf("%s %40s\n", output_hex_buf, output_ascii_buf);
		}
	}
}


void
tipcdump_stats_wfile()
{
	ssize_t		size;
	unsigned int	buf;


	/*
	** Write the "magic" size field to indicate this is a stats dump.
	*/
	buf = TIPCDUMP_STATS_LOGGED;
	size = write(tipcdump_info.wfd, &buf, 4);
	if (size != 4)
	{
		fprintf(stderr, "%s: ERROR: write stats size field failed, errno=%d\n",
			tipcdump_info.prog,
			errno);
		tipcdump_exit(-1);
	}

	/*
	** Write the stats buffer as-is.
	*/
	size = write(tipcdump_info.wfd, &(tipcdump_info.stats), sizeof(tipcdump_stats_t));
	if (size != sizeof(tipcdump_stats_t))
	{
		fprintf(stderr, "%s: ERROR: write stats structure failed, errno=%d\n",
			tipcdump_info.prog,
			errno);
		tipcdump_exit(-1);
	}
}


void
tipcdump_message_wfile()
{
	ssize_t		size;


	/*
	** First adjust the size back to include the timestamp and message direction.
	*/
	tipcdump_buf.size += TIPCDUMP_TRAILER_SIZE;

	/*
	** Write the size as the first 4 bytes of the message. Used when we read the
	** message back in as a file.
	*/
	size = write(tipcdump_info.wfd, &(tipcdump_buf.size), 4);
	if (size != 4)
	{
		fprintf(stderr, "%s: ERROR: write buffer size failed, errno=%d\n",
			tipcdump_info.prog,
			errno);
		tipcdump_exit(-1);
	}

	size = write(tipcdump_info.wfd, tipcdump_buf.buf, tipcdump_buf.size);
	if (size != tipcdump_buf.size)
	{
		fprintf(stderr, "%s: ERROR: write buffer failed, errno=%d\n",
			tipcdump_info.prog,
			errno);
		tipcdump_exit(-1);
	}
}


void
tipcdump_set_message_fields()
{
	tipcdump_buf.size -= TIPCDUMP_TRAILER_SIZE;

	tipcdump_buf.msg_direction = tipcdump_buf.buf[tipcdump_buf.size];

	tipcdump_buf.msg_sec =
		(time_t) (tipcdump_buf.buf[tipcdump_buf.size + 1] << 24) |
		(tipcdump_buf.buf[tipcdump_buf.size + 2] << 16) |
		(tipcdump_buf.buf[tipcdump_buf.size + 3] << 8) |
		tipcdump_buf.buf[tipcdump_buf.size + 4];
	tipcdump_buf.msg_sec = ntohl(tipcdump_buf.msg_sec);

	tipcdump_buf.msg_usec =
		(suseconds_t) (tipcdump_buf.buf[tipcdump_buf.size + 5] << 24) |
		(tipcdump_buf.buf[tipcdump_buf.size + 6] << 16) |
		(tipcdump_buf.buf[tipcdump_buf.size + 7] << 8) |
		tipcdump_buf.buf[tipcdump_buf.size + 8];
	tipcdump_buf.msg_usec = ntohl(tipcdump_buf.msg_usec);

	tipcdump_buf.msg_type = TIPCDUMP_MSG_TYPE(tipcdump_buf.buf[4]);

	tipcdump_buf.orig_node =
		(tipcdump_buf.buf[24] << 24) |
		(tipcdump_buf.buf[25] << 16) |
		(tipcdump_buf.buf[26] << 8) |
		tipcdump_buf.buf[27];
	tipcdump_buf.orig_node = ntohl(tipcdump_buf.orig_node);

	tipcdump_buf.dest_node =
		(tipcdump_buf.buf[28] << 24) |
		(tipcdump_buf.buf[29] << 16) |
		(tipcdump_buf.buf[30] << 8) |
		tipcdump_buf.buf[31];
	tipcdump_buf.dest_node = ntohl(tipcdump_buf.dest_node);

	tipcdump_buf.type =
		(tipcdump_buf.buf[32] << 24) |
		(tipcdump_buf.buf[33] << 16) |
		(tipcdump_buf.buf[34] << 8) |
		tipcdump_buf.buf[35];
	tipcdump_buf.type = ntohl(tipcdump_buf.type);

	tipcdump_buf.instance =
		(tipcdump_buf.buf[36] << 24) |
		(tipcdump_buf.buf[37] << 16) |
		(tipcdump_buf.buf[38] << 8) |
		tipcdump_buf.buf[39];
	tipcdump_buf.instance = ntohl(tipcdump_buf.instance);
}


void
tipcdump_filter_message(int *good_message)
{
	int		zone, cluster, node;


	if (*good_message == TRUE && tipcdump_info.Sflag > 0)
	{
		if (tipcdump_buf.msg_direction == TIPCDUMP_MSG_SENT)
		{
			/*
			** Reject this message.
			*/
			*good_message = FALSE;
		}
	}

	if (*good_message == TRUE && tipcdump_info.Rflag > 0)
	{
		if (tipcdump_buf.msg_direction == TIPCDUMP_MSG_RECEIVED)
		{
			/*
			** Reject this message.
			*/
			*good_message = FALSE;
		}
	}

	if (*good_message == TRUE && tipcdump_info.Iflag > 0)
	{
		if (tipcdump_buf.msg_type > 3)
		{
			/*
			** Reject this message.
			*/
			*good_message = FALSE;
		}
	}

	if (*good_message == TRUE && tipcdump_info.Pflag > 0)
	{
		if (tipcdump_buf.msg_type <= 3)
		{
			/*
			** Reject this message.
			*/
			*good_message = FALSE;
		}
	}

	if (*good_message == TRUE)
	{
		if (tipcdump_info.oflag)
		{
			zone = ZONE(tipcdump_buf.orig_node);
			cluster = CLUSTER(tipcdump_buf.orig_node);
			node = NODE(tipcdump_buf.orig_node);

			if ( (zone < tipcdump_info.oz1 || zone > tipcdump_info.oz2) ||
				  (cluster < tipcdump_info.oc1 || cluster > tipcdump_info.oc2) ||
				  (node < tipcdump_info.on1 || node > tipcdump_info.on2) )
			{
				/*
				** Reject this message.
				*/
				*good_message = FALSE;
			}
		}
	}

	if (*good_message == TRUE)
	{
		if (tipcdump_info.dflag)
		{
			zone = ZONE(tipcdump_buf.dest_node);
			cluster = CLUSTER(tipcdump_buf.dest_node);
			node = NODE(tipcdump_buf.dest_node);

			if ( (zone < tipcdump_info.dz1 || zone > tipcdump_info.dz2) ||
				  (cluster < tipcdump_info.dc1 || cluster > tipcdump_info.dc2) ||
				  (node < tipcdump_info.dn1 || node > tipcdump_info.dn2) )
			{
				/*
				** Reject this message.
				*/
				*good_message = FALSE;
			}
		}
	}

	if (*good_message == TRUE)
	{
		if (tipcdump_info.iflag)
		{
			if (tipcdump_buf.msg_type == 2)
			{
				if (tipcdump_buf.instance < tipcdump_info.i_lower ||
					tipcdump_buf.instance > tipcdump_info.i_upper)
				{
					/*
					** Reject this message.
					*/
					*good_message = FALSE;
				}
			}
			else
			{
				/*
				** Message type indicates there is no instance field, reject this message.
				*/
				*good_message = FALSE;
			}
		}
	}

	if (*good_message == TRUE)
	{
		if (tipcdump_info.tflag)
		{
			if (tipcdump_buf.msg_type == 2)
			{
				if ((tipcdump_buf.type & tipcdump_info.t_bitmask) != tipcdump_info.t_result)
				{
					/*
					** Reject this message.
					*/
					*good_message = FALSE;
				}
			}
			else
			{
				/*
				** Message type indicates there is no type field, reject this message.
				*/
				*good_message = FALSE;
			}
		}
	}

	/*
	** Update the total stats.
	*/
	if (tipcdump_buf.msg_direction == TIPCDUMP_MSG_SENT)
	{
		(tipcdump_info.stats.t_msg_sent)++;
		tipcdump_info.stats.t_bytes_sent += tipcdump_buf.size;

		if ( (tipcdump_buf.orig_node == tipcdump_buf.dest_node) &&
			 (tipcdump_buf.orig_node == tipcdump_info.mynode) )
		{
			(tipcdump_info.stats.t_local_msg_sent)++;
			tipcdump_info.stats.t_local_bytes_sent += tipcdump_buf.size;
		}
	}
	else
	{
		(tipcdump_info.stats.t_msg_recv)++;
		tipcdump_info.stats.t_bytes_recv += tipcdump_buf.size;

		if ( (tipcdump_buf.orig_node == tipcdump_buf.dest_node) &&
			 (tipcdump_buf.orig_node == tipcdump_info.mynode) )
		{
			(tipcdump_info.stats.t_local_msg_recv)++;
			tipcdump_info.stats.t_local_bytes_recv += tipcdump_buf.size;
		}
	}

	/*
	** Update the filtered stats, only if the message is to be retained.
	*/
	if (*good_message == TRUE)
	{
		if (tipcdump_buf.msg_direction == TIPCDUMP_MSG_SENT)
		{
			(tipcdump_info.stats.f_msg_sent)++;
			tipcdump_info.stats.f_bytes_sent += tipcdump_buf.size;

			if ( (tipcdump_buf.orig_node == tipcdump_buf.dest_node) &&
				 (tipcdump_buf.orig_node == tipcdump_info.mynode) )
			{
				(tipcdump_info.stats.f_local_msg_sent)++;
				tipcdump_info.stats.f_local_bytes_sent += tipcdump_buf.size;
			}
		}
		else
		{
			(tipcdump_info.stats.f_msg_recv)++;
			tipcdump_info.stats.f_bytes_recv += tipcdump_buf.size;

			if ( (tipcdump_buf.orig_node == tipcdump_buf.dest_node) &&
				 (tipcdump_buf.orig_node == tipcdump_info.mynode) )
			{
				(tipcdump_info.stats.f_local_msg_recv)++;
				tipcdump_info.stats.f_local_bytes_recv += tipcdump_buf.size;
			}
		}
	}

	return;
}


int
tipcdump_process()
{
	int				retval = 0, good_message;
	ssize_t			size;
	off_t			offset;
	struct stat		filestats;


	if (tipcdump_info.rfilename != NULL)
	{
		tipcdump_info.rfd = open(tipcdump_info.rfilename, O_RDONLY);
		if (tipcdump_info.rfd == -1)
		{
			fprintf(stderr, "%s: ERROR: open read file %s, errno=%d\n",
				tipcdump_info.prog,
				tipcdump_info.rfilename,
				errno);
			tipcdump_exit(-1);
		}

		offset = lseek(tipcdump_info.rfd, 0, SEEK_SET);
		if (offset == -1)
		{
			fprintf(stderr, "%s: ERROR: lseek read file %s, errno=%d\n",
				tipcdump_info.prog,
				tipcdump_info.rfilename,
				errno);
			tipcdump_exit(-1);
		}
		printf("Using (recorded) data from file '%s'\n", tipcdump_info.rfilename);
	}
	else
	{
		tipcdump_info.devfd = open(tipcdump_info.devfile, O_RDONLY);
		if (tipcdump_info.devfd == -1)
		{
			fprintf(stderr, "%s: ERROR: open character file %s, errno=%d\n",
				tipcdump_info.prog,
				tipcdump_info.devfile,
				errno);
			tipcdump_exit(-1);
		}

		retval = ioctl(tipcdump_info.devfd, TIPCDUMP_IOCTL_GET_OWN_NODE, (uint32_t) &(tipcdump_info.mynode));
		if (retval != 0)
		{
			fprintf(stderr, "%s: ERROR: ioctl TIPCDUMP_IOCTL_GET_OWN_NODE failed, errno=%d\n",
				tipcdump_info.prog,
				errno);
			tipcdump_exit(-1);
		}
		printf("Using (live) data from TIPC kernel module, my node=%d.%d.%d\n",
			ZONE(tipcdump_info.mynode),
			CLUSTER(tipcdump_info.mynode),
			NODE(tipcdump_info.mynode));
	}

	if (tipcdump_info.wfilename != NULL)
	{
		retval = stat(tipcdump_info.wfilename, &filestats);
		if (retval == -1)
		{
			if (errno == ENOENT)
			{
				/*
				** This is OK, file does not exist.
				*/
			}
			else
			{
				fprintf(stderr, "%s: ERROR: stat failed with errno=%d\n",
					tipcdump_info.prog,
					errno);
				tipcdump_exit(-1);
			}
		}
		else
		{
			fprintf(stderr, "%s: ERROR: file %s already exists\n",
				tipcdump_info.prog,
				tipcdump_info.wfilename);
			tipcdump_exit(-1);
		}

		tipcdump_info.wfd = open(tipcdump_info.wfilename, (O_CREAT | O_WRONLY));
		if (tipcdump_info.wfd == -1)
		{
			fprintf(stderr, "%s: ERROR: open write file %s, errno=%d\n",
				tipcdump_info.prog,
				tipcdump_info.wfilename,
				errno);
			tipcdump_exit(-1);
		}

		retval = fchmod(tipcdump_info.wfd,
			(S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH));
		if (retval == -1)
		{
			fprintf(stderr, "%s: ERROR: chmod write file %s, errno=%d\n",
				tipcdump_info.prog,
				tipcdump_info.wfilename,
				errno);
			tipcdump_exit(-1);
		}
		printf("Writing data to file '%s'\n", tipcdump_info.wfilename);
	}
	else
	{
		printf("Writing data to stdout\n");
	}

	while (1)
	{
		good_message = FALSE;

		if (tipcdump_info.rfd != -1)
		{
			/*
			** Read message from data file.
			*/
			size = read(tipcdump_info.rfd, &(tipcdump_buf.size), 4);
			if (size != 4)
			{
				tipcdump_exit(0);
			}

			if (tipcdump_buf.size == TIPCDUMP_STATS_LOGGED)
			{
				size = read(tipcdump_info.rfd, &(tipcdump_info.stats), sizeof(tipcdump_stats_t));
				if (size != sizeof(tipcdump_stats_t))
				{
					fprintf(stderr, "%s: ERROR: read stats failed, errno=%d\n",
						tipcdump_info.prog,
						errno);
					tipcdump_exit(-1);
				}
				tipcdump_info.dumpstats = TRUE;
			}
			else
			{
				size = read(tipcdump_info.rfd, tipcdump_buf.buf, tipcdump_buf.size);
				if (size != tipcdump_buf.size)
				{
					fprintf(stderr, "%s: ERROR: read buffer failed, errno=%d\n",
						tipcdump_info.prog,
						errno);
					tipcdump_exit(-1);
				}
				else
				{
					good_message = TRUE;
				}
			}
		}
		else
		{
			tipcdump_buf.size = read(tipcdump_info.devfd, tipcdump_buf.buf, TIPCDUMP_MAX_PAYLOAD_SIZE);
			if ( (tipcdump_buf.size == 0) && (tipcdump_info.dumpstats == 0) &&
				 (tipcdump_info.exit == 0) && ( (errno == 0) || (errno == 2) ) )
			{
				return(0);
			}
			if ( (tipcdump_buf.size <= 0) && (tipcdump_info.dumpstats == 0) && (tipcdump_info.exit == 0) )
			{
				fprintf(stderr, "%s: ERROR: read failed, errno=%d\n",
					tipcdump_info.prog,
					errno);
				continue;
			}
			else
			{
				good_message = TRUE;
			}
		}

		/*
		** Did a SIGUSR1 arrive for dumping stats?
		*/
		if (tipcdump_info.dumpstats == TRUE && tipcdump_info.rfd == -1)
		{
			/*
			** Fetch the dropped_messages count due to overflow queue.
			*/
			if (retval == -1)
			{
				fprintf(stderr, "%s: ERROR: gettimeofday failed, errno=%d\n",
					tipcdump_info.prog,
					errno);
			}
			else
			{
				if (tipcdump_info.wfd != -1)
				{
					/*
					** Dump stats to wfilename.
					*/
					tipcdump_stats_wfile();
				}
				else
				{
					/*
					** Dump stats to stdout.
					*/
					tipcdump_stats_stdout();
				}
			}
			tipcdump_info.dumpstats = FALSE;
			continue;
		}

		/*
		** Did a stats structure just get read in from the read data file?
		*/
		if (tipcdump_info.dumpstats == TRUE && tipcdump_info.rfd != -1)
		{
			if (tipcdump_info.wfd != -1)
			{
				/*
				** Dump stats to wfilename.
				*/
				tipcdump_stats_wfile();
			}
			else
			{
				/*
				** Dump stats to stdout.
				*/
				tipcdump_stats_stdout();
			}

			tipcdump_info.dumpstats = FALSE;
			continue;
		}

		/*
		** Did a SIGINT arrive for dumping stats and exiting?
		*/
		if (tipcdump_info.exit == TRUE)
		{
			/*
			** Fetch the dropped_messages count due to overflow queue.
			*/
			ioctl(tipcdump_info.devfd, TIPCDUMP_IOCTL_GET_DROPPED_COUNT,
				(uint32_t) &(tipcdump_info.stats.dropped_messages));

			/*
			** Update the current time in the stats structure.
			*/
			retval = gettimeofday(&(tipcdump_info.stats.curr_time), NULL);
			if (retval == -1)
			{
				fprintf(stderr, "%s: ERROR: gettimeofday failed, errno=%d\n",
					tipcdump_info.prog,
					errno);
			}
			else
			{
				if (tipcdump_info.wfd != -1)
				{
					/*
					** Dump stats to wfilename.
					*/
					tipcdump_stats_wfile();
				}
				else
				{
					/*
					** Dump stats to stdout.
					*/
					tipcdump_stats_stdout();
				}
			}

			break;
		}

		/*
		** A message is sitting in the global buf. Set up the fields and then
		** filter the message with the specified runtime flags. If the message
		** falls through the filters, then print or log it. Otherwise, continue
		** on with the next message.
		*/
		if (good_message == TRUE)
		{
			tipcdump_set_message_fields();
			tipcdump_filter_message(&good_message);
		}

		if (good_message == TRUE)
		{
			if (tipcdump_info.wfd != -1)
			{
				/*
				** Dump message to wfilename.
				*/
				tipcdump_message_wfile();
			}
			else
			{
				/*
				** Dump message to stdout.
				*/
				tipcdump_message_stdout();
			}
		}

		/*
		** If -c <cnt> was specified, count the messages received and
		** break if we need to quit now.
		*/
		if (tipcdump_info.cflag)
		{
			if (tipcdump_info.stats.f_msg_recv == tipcdump_info.count)
			{
				/*
				** Fetch the dropped_messages count due to overflow queue.
				*/
				ioctl(tipcdump_info.devfd, TIPCDUMP_IOCTL_GET_DROPPED_COUNT,
					(uint32_t) &(tipcdump_info.stats.dropped_messages));

				/*
				** Update the current time in the stats structure.
				*/
				retval = gettimeofday(&(tipcdump_info.stats.curr_time), NULL);
				if (retval == -1)
				{
					fprintf(stderr, "%s: ERROR: gettimeofday failed, errno=%d\n",
						tipcdump_info.prog,
						errno);
				}
				else
				{
					if (tipcdump_info.wfd != -1)
					{
						/*
						** Dump stats to wfilename.
						*/
						tipcdump_stats_wfile();
					}
					else
					{
						/*
						** Dump stats to stdout.
						*/
						tipcdump_stats_stdout();
					}
				}

				break;
			}
		}
	}

	/*
	** Done processing.
	*/
	return(0);
}


int
main(int argc, char* argv[], char* dummy[])
{
	int retval = 0;


	retval = tipcdump_initialize(argc, argv);
	if (retval != 0)
	{
		tipcdump_exit(-1);
	}

	retval = tipcdump_parse_args(argc, argv);
	if (retval != 0)
	{
		tipcdump_exit(-1);
	}

	retval = tipcdump_process();
	if (retval != 0)
	{
		tipcdump_exit(-1);
	}

	tipcdump_exit(0);
	return(0);
}
