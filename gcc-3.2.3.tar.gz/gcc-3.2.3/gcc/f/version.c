#include "ansidecl.h"
#include "f/version.h"

const char *const ffe_version_string = "3.2.3 20030422 (release)";
