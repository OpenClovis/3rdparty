#ifndef GCC_F_VERSION_H
#define GCC_F_VERSION_H

extern const char *const ffe_version_string;

#endif /* ! GCC_F_VERSION_H */
