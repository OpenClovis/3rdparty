/*      -*- c++ -*-
 *
 * Copyright (C) 2011, Pigeon Point Systems
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  This
 * file and program are licensed under a BSD style license.  See
 * the Copying file included with the OpenHPI distribution for
 * full licensing terms.
 *
 * Author(s):
 *      Anton Pak <anton.pak@pigeonpoint.com>
 */

#ifndef SCHEMA_H_EC5AF80F_A79B_49D7_8371_F71504C426A6
#define SCHEMA_H_EC5AF80F_A79B_49D7_8371_F71504C426A6


extern "C"
{

extern char schema_begin;
extern char schema_end;

};


#endif /* SCHEMA_H_EC5AF80F_A79B_49D7_8371_F71504C426A6 */

