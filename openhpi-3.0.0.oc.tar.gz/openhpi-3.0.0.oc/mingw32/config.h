#ifndef __OPENHPI_CONFIG_H
#define __OPENHPI_CONFIG_H


#define OH_CLIENT_DEFAULT_CONF ""
#define OH_DEFAULT_CONF ""
#define OH_DEFAULT_UID_MAP ""
#define OH_PLUGIN_PATH ""
#define VARPATH ""


#endif /* __OPENHPI_CONFIG_H */

